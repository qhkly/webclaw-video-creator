/**
 * 会话状态（框架无关）。只有 reducer 式的纯更新 + 订阅，所有 I/O 在 session.js。
 *
 * 不变式（各站已踩过的坑，集中在这里裁决一次）：
 *   1. 账号隔离：状态按 identityKey(app|uid) 分桶。身份一变整份清空，任何携带旧 identityKey
 *      的结果（迟到的 poll / 发送回执 / typing）一律丢弃 —— 不把 A 的消息、游标带给 B。
 *   2. 消息按 id 去重、按 id 升序；lastId = 已确认消息的最大 id，poll 的 since 只取它。
 *   3. 乐观消息用 clientId，绝不占用正整数 id；回执到了才转正。
 *   4. 模式（ai / human_requested / human）以服务端为准，但本地动作（转人工/返回 AI）之后
 *      才发出的 poll 结果才能覆盖它：modeSeq 防「旧 poll 把刚点的按钮又改回去」。
 *   5. typing 只认 rev 不更旧的结果；任何新的非用户消息到达即清除（回复来了就不再「正在输入」）。
 */

import { SUPPORT_MODES } from './protocol.js';

/** typing 显示上限：服务端 AI 45s / 人工 7s，客户端再兜一层，防止丢了「结束」帧后永远显示 */
export const TYPING_MAX_MS = 45_000;

export function initialState(identityKey = null) {
  return {
    identityKey,
    loaded: false,
    messages: [],
    pending: [],
    lastId: 0,
    threadStatus: 'none',
    supportMode: SUPPORT_MODES.AI,
    modeSeq: 0,
    typing: null, // {actor, expiresAt}
    typingRev: null,
    typingPush: false,
    feedbackEnabled: false,
    feedbackBusy: {}, // msgId → true（等服务端确认）
    schedule: null,
    unread: 0,
    connected: false,
    error: null,
  };
}

export function createSupportStore({ now = () => Date.now() } = {}) {
  let state = initialState();
  const listeners = new Set();

  const set = (next) => {
    if (next === state) return;
    state = next;
    for (const l of [...listeners]) l(state);
  };
  const same = (key) => key === undefined || key === state.identityKey;

  function mergeMessages(list) {
    if (!list.length) return null;
    const byId = new Map(state.messages.map((m) => [m.id, m]));
    let arrivedReply = false;
    for (const m of list) {
      const prev = byId.get(m.id);
      // 已有消息只更新评价/可评价（同一 id 的正文服务端不改）
      byId.set(m.id, prev ? { ...prev, rateable: m.rateable, feedback: m.feedback } : m);
      if (!prev && m.kind !== 'user') arrivedReply = true;
    }
    const messages = [...byId.values()].sort((a, b) => a.id - b.id);
    return { messages, lastId: messages.length ? messages[messages.length - 1].id : 0, arrivedReply };
  }

  function typingFrom(t) {
    if (!t) return null;
    return { actor: t.actor, expiresAt: now() + Math.min(t.ttlMs || TYPING_MAX_MS, TYPING_MAX_MS) };
  }

  return {
    getState: () => state,
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    /** 身份变化（含首次）：整份重置。同一身份重复调用不清空 */
    setIdentity(identityKey) {
      if (identityKey === state.identityKey) return false;
      set(initialState(identityKey));
      return true;
    },

    /**
     * 应用一次 poll。
     * @param {object} r            client.poll() 的结果（带 identityKey）
     * @param {number} [modeSeqAtStart]  发起 poll 时的 modeSeq；之后有本地模式动作则不采纳本次 mode
     */
    applyPoll(r, modeSeqAtStart = state.modeSeq) {
      if (!same(r.identityKey)) return false;
      const merged = mergeMessages(r.messages || []);
      const next = { ...state, loaded: true, error: null, threadStatus: r.status, typingPush: r.typingPush, feedbackEnabled: r.feedbackEnabled, schedule: r.schedule };
      if (merged) {
        next.messages = merged.messages;
        next.lastId = Math.max(state.lastId, merged.lastId);
        // 已转正的乐观消息：正式消息到了就移除（只按回执给的 id 对，不按文本猜）
        const ids = new Set(merged.messages.map((m) => m.id));
        next.pending = state.pending.filter((p) => !(p.id && ids.has(p.id)));
        if (merged.arrivedReply) next.typing = null;
      }
      if (modeSeqAtStart === state.modeSeq) next.supportMode = r.supportMode;
      if (r.typing !== undefined && !(merged && merged.arrivedReply)) {
        if (r.typingRev == null || state.typingRev == null || r.typingRev >= state.typingRev) {
          next.typing = typingFrom(r.typing);
          if (r.typingRev != null) next.typingRev = r.typingRev;
        }
      }
      set(next);
      return true;
    },

    /** 推送帧 / /api/typing 单次同步 */
    applyTyping({ typing, rev, identityKey } = {}) {
      if (!same(identityKey)) return false;
      if (rev != null && state.typingRev != null && rev < state.typingRev) return false;
      set({ ...state, typing: typingFrom(typing), typingRev: rev ?? state.typingRev });
      return true;
    },

    /** 当前是否在显示 typing（过期即 false；UI 每次渲染调一次即可，不需要定时器写状态） */
    activeTyping(at = now()) {
      return state.typing && state.typing.expiresAt > at ? state.typing.actor : null;
    },

    addPending({ clientId, text, files = [] }) {
      set({ ...state, pending: [...state.pending, { clientId, text, files, state: 'sending', at: now() }] });
    },
    /**
     * 发送回执到了：带真实 id 的乐观消息先标 sent，等 poll 拉到同 id 的正式消息再移除，
     * 避免「回执 → poll」之间气泡闪没。id=0（拉黑静默接受）直接移除。
     */
    resolvePending(clientId, { id = 0, identityKey } = {}) {
      if (!same(identityKey)) return false;
      const known = id > 0 && state.messages.some((m) => m.id === id);
      const pending = id > 0 && !known
        ? state.pending.map((p) => (p.clientId === clientId ? { ...p, state: 'sent', id } : p))
        : state.pending.filter((p) => p.clientId !== clientId);
      set({ ...state, pending });
      return true;
    },
    dropPending(clientId) {
      set({ ...state, pending: state.pending.filter((p) => p.clientId !== clientId) });
    },
    failPending(clientId, error) {
      set({ ...state, pending: state.pending.map((p) => (p.clientId === clientId ? { ...p, state: 'failed', error } : p)) });
    },

    /** 本地模式动作的结果（handoff / ai-resume 的回执，或 409 里的 mode） */
    setMode(mode, { identityKey } = {}) {
      if (!same(identityKey) || !Object.values(SUPPORT_MODES).includes(mode)) return false;
      set({ ...state, supportMode: mode, modeSeq: state.modeSeq + 1 });
      return true;
    },
    bumpModeSeq() {
      set({ ...state, modeSeq: state.modeSeq + 1 });
    },

    setFeedbackBusy(msgId, busy) {
      const feedbackBusy = { ...state.feedbackBusy };
      if (busy) feedbackBusy[msgId] = true;
      else delete feedbackBusy[msgId];
      set({ ...state, feedbackBusy });
    },
    /** 服务端确认后的评价（null = 已取消） */
    setFeedback(msgId, feedback, { identityKey } = {}) {
      if (!same(identityKey)) return false;
      set({ ...state, messages: state.messages.map((m) => (m.id === msgId ? { ...m, feedback } : m)) });
      return true;
    },
    /** 某条消息服务端说不能评（not_found / not_rateable）：只收起这一条 */
    markUnrateable(msgId) {
      set({ ...state, messages: state.messages.map((m) => (m.id === msgId ? { ...m, rateable: false } : m)) });
    },
    /** 服务端没开评价（unavailable）：全部收起 */
    disableFeedback() {
      set({ ...state, feedbackEnabled: false });
    },
    reconcileFeedback(map, { identityKey } = {}) {
      if (!same(identityKey)) return false;
      set({ ...state, messages: state.messages.map((m) => (map.has(m.id) && m.rateable ? { ...m, feedback: map.get(m.id) } : m)) });
      return true;
    },

    setUnread(n, { identityKey } = {}) {
      if (!same(identityKey)) return false;
      set({ ...state, unread: Math.max(0, Number(n) || 0) });
      return true;
    },
    setConnected(connected) {
      if (connected !== state.connected) set({ ...state, connected });
    },
    setError(error) {
      set({ ...state, error });
    },
  };
}

/** UI 用：某条消息能不能显示评价按钮 */
export function canRate(state, m) {
  return state.feedbackEnabled === true && m.kind === 'ai' && m.rateable === true && m.id > 0;
}
