/**
 * Widget 主题：各产品只给「品牌参数」，配色体系由这里统一推导。
 *
 *   primary        品牌主色（按钮、用户气泡、角标）            必填，#rgb / #rrggbb
 *   primaryDark    深色模式下的主色（不给则自动提亮 primary）
 *   fontFamily     字体栈（不给则跟随宿主页面 inherit）
 *   radius         圆角 px（0–28）；气泡/按钮/面板按比例派生
 *   icon           启动按钮图标：'chat' | 'headset' | 'help' | 图片 URL（https: / data:image/）
 *   colorScheme    'auto'（跟随系统）| 'light' | 'dark' | 'document'（跟随宿主 <html> 的 dark 类 / data-theme）
 *   light / dark   可选的表面色覆盖：{ bg, surface, text, muted, border, agentBubble }
 *
 * 所有输入都校验：值会写进 CSS，**不合法即回退默认**，不让宿主配置注入样式规则。
 */

export const COLOR_SCHEMES = Object.freeze(['auto', 'light', 'dark', 'document']);
export const BUILTIN_ICONS = Object.freeze(['chat', 'headset', 'help']);

const PALETTE = Object.freeze({
  light: { bg: '#ffffff', surface: '#f4f5f7', text: '#16181d', muted: '#5f6673', border: '#e1e4ea', agentBubble: '#f1f2f5' },
  dark: { bg: '#17191e', surface: '#20232a', text: '#eceef2', muted: '#a2a9b6', border: '#2f333c', agentBubble: '#262a32' },
});

export const DEFAULT_THEME = Object.freeze({
  primary: '#2563eb',
  primaryDark: null,
  fontFamily: null,
  radius: 14,
  icon: 'chat',
  colorScheme: 'auto',
});

const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;

export function isColor(v) {
  return typeof v === 'string' && HEX.test(v.trim());
}

/** 字体栈：不许出现能结束声明/规则的字符；引号必须成对 */
export function isFontFamily(v) {
  if (typeof v !== 'string') return false;
  const s = v.trim();
  if (!s || s.length > 200 || /[;{}<>\\@]|\/\*/.test(s)) return false;
  return (s.match(/"/g) || []).length % 2 === 0 && (s.match(/'/g) || []).length % 2 === 0;
}

/** 图标 URL：只收 https 与 data:image（<img> 里的 SVG 不执行脚本） */
export function isIconUrl(v) {
  if (typeof v !== 'string') return false;
  if (/^data:image\/(png|jpeg|gif|webp|svg\+xml)[;,]/i.test(v)) return v.length < 64_000;
  try {
    const u = new URL(v, 'https://x.invalid');
    return u.protocol === 'https:' || (u.protocol === 'http:' && /^(localhost|127\.0\.0\.1)$/.test(u.hostname))
      || (u.hostname === 'x.invalid' && v.startsWith('/'));
  } catch {
    return false;
  }
}

function expand(hex) {
  const h = hex.trim().slice(1);
  return h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
}
function toRgb(hex) {
  const h = expand(hex);
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
}
function toHex(rgb) {
  return `#${rgb.map((x) => Math.round(Math.max(0, Math.min(255, x))).toString(16).padStart(2, '0')).join('')}`;
}
function mix(a, b, t) {
  const x = toRgb(a);
  const y = toRgb(b);
  return toHex(x.map((v, i) => v + (y[i] - v) * t));
}

/** WCAG 相对亮度 */
export function luminance(hex) {
  const [r, g, b] = toRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a, b) {
  const [x, y] = [luminance(a), luminance(b)].sort((m, n) => n - m);
  return (x + 0.05) / (y + 0.05);
}

/** 主色上的文字色：白/近黑里对比度高的那个 */
export function onColor(hex) {
  return contrast(hex, '#ffffff') >= contrast(hex, '#111318') ? '#ffffff' : '#111318';
}

/** 深色背景上主色太暗时逐步提亮，直到与背景对比度 ≥ 3（WCAG 非文本 UI） */
export function liftForDark(hex, bg = PALETTE.dark.bg) {
  let c = hex;
  for (let i = 0; i < 10 && contrast(c, bg) < 3; i++) c = mix(c, '#ffffff', 0.15);
  return c;
}

function cleanPalette(input, base) {
  const out = { ...base };
  if (input && typeof input === 'object') {
    for (const k of Object.keys(base)) if (isColor(input[k])) out[k] = input[k].trim();
  }
  return out;
}

/** 宿主输入 → 校验后的完整主题。未知/非法值一律回退默认 */
export function normalizeTheme(input = {}, base = DEFAULT_THEME) {
  const src = input && typeof input === 'object' ? input : {};
  const prev = base && typeof base === 'object' ? base : DEFAULT_THEME;
  const radiusNum = Number(src.radius);
  const icon = BUILTIN_ICONS.includes(src.icon) || isIconUrl(src.icon) ? src.icon : prev.icon ?? DEFAULT_THEME.icon;
  return {
    primary: isColor(src.primary) ? src.primary.trim() : prev.primary ?? DEFAULT_THEME.primary,
    primaryDark: isColor(src.primaryDark) ? src.primaryDark.trim() : src.primary !== undefined && isColor(src.primary) ? null : prev.primaryDark ?? null,
    fontFamily: isFontFamily(src.fontFamily) ? src.fontFamily.trim() : src.fontFamily === null ? null : prev.fontFamily ?? null,
    radius: src.radius !== undefined && Number.isFinite(radiusNum) ? Math.max(0, Math.min(28, Math.round(radiusNum))) : prev.radius ?? DEFAULT_THEME.radius,
    icon,
    colorScheme: COLOR_SCHEMES.includes(src.colorScheme) ? src.colorScheme : prev.colorScheme ?? DEFAULT_THEME.colorScheme,
    light: cleanPalette(src.light, prev.light || PALETTE.light),
    dark: cleanPalette(src.dark, prev.dark || PALETTE.dark),
  };
}

/** 把底色调到与文字色对比度 ≥ min（向文字色反方向混合，最多 12 步）：品牌色过亮 / 过艳时气泡仍可读 */
export function ensureContrast(bg, fg, min = 4.5) {
  const target = luminance(fg) > 0.5 ? '#000000' : '#ffffff';
  let c = bg;
  for (let i = 0; i < 12 && contrast(c, fg) < min; i++) c = mix(c, target, 0.1);
  return c;
}

/** 一个配色方案的全部 CSS 变量 */
export function schemeTokens(theme, scheme) {
  const p = scheme === 'dark' ? theme.dark : theme.light;
  const primary = scheme === 'dark' ? theme.primaryDark || liftForDark(theme.primary, p.bg) : theme.primary;
  const r = theme.radius;
  const bubble = Math.min(18, Math.max(4, Math.round(r * 1.1)));
  // 用户气泡：品牌色，但保证白/黑字 ≥ 4.5:1，且不整片过亮；accent 只用于小面积（气泡、按钮、发言标识）
  const userBubble = ensureContrast(primary, onColor(primary));
  return {
    '--wsu-primary': primary,
    '--wsu-on-primary': onColor(primary),
    '--wsu-user-bubble': userBubble,
    '--wsu-on-user-bubble': onColor(userBubble),
    '--wsu-primary-soft': mix(primary, p.bg, scheme === 'dark' ? 0.78 : 0.88),
    '--wsu-bg': p.bg,
    '--wsu-surface': p.surface,
    '--wsu-text': p.text,
    '--wsu-muted': p.muted,
    '--wsu-border': p.border,
    '--wsu-agent-bubble': p.agentBubble,
    '--wsu-danger': scheme === 'dark' ? '#f87171' : '#c62828',
    '--wsu-shadow': scheme === 'dark' ? '0 12px 40px rgba(0,0,0,.55)' : '0 12px 40px rgba(17,24,39,.18)',
    '--wsu-radius': `${r}px`,
    '--wsu-radius-sm': `${Math.round(r * 0.6)}px`,
    '--wsu-radius-bubble': `${bubble}px`,
    '--wsu-radius-tail': `${Math.min(4, bubble)}px`,
    '--wsu-radius-composer': `${Math.min(14, Math.max(6, Math.round(r * 0.8)))}px`,
  };
}

const decl = (tokens) => Object.entries(tokens).map(([k, v]) => `${k}:${v};`).join('');

/**
 * 主题 → shadow root 内的 CSS。宿主元素上的 data-scheme 决定生效哪套：
 *   light / dark 固定；auto 跟随 prefers-color-scheme；document 由 widget 观察宿主页面后写 light/dark。
 */
export function themeCss(theme) {
  const font = theme.fontFamily ? `--wsu-font:${theme.fontFamily};` : '--wsu-font:inherit;';
  const light = decl(schemeTokens(theme, 'light'));
  const dark = decl(schemeTokens(theme, 'dark'));
  return [
    `:host{${font}${light}color-scheme:light;}`,
    `:host([data-scheme="dark"]){${dark}color-scheme:dark;}`,
    `@media (prefers-color-scheme: dark){:host([data-scheme="auto"]){${dark}color-scheme:dark;}}`,
  ].join('\n');
}

/** 'document' 模式：读宿主页面当前是否深色（Next.js 站常见的 html.dark / data-theme） */
export function documentPrefersDark(doc = globalThis.document) {
  const el = doc?.documentElement;
  if (!el) return false;
  if (el.classList.contains('dark')) return true;
  const attr = el.getAttribute('data-theme') || el.getAttribute('data-color-scheme') || el.style.colorScheme;
  return /^dark$/i.test(String(attr || '').trim());
}
