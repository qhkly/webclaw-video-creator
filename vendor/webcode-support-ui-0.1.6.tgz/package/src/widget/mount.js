/**
 * 一行 script 嵌入。打包成 dist/webcode-support.js（IIFE，全局 WebcodeSupport），或直接以 ESM 引入。
 *
 *   <script src="/support/webcode-support.js" defer
 *           data-app="ccdub" data-auth="session"
 *           data-primary="#e11d48" data-radius="16" data-font="Inter, sans-serif"
 *           data-icon="headset" data-color-scheme="document" data-lang="zh-CN"></script>
 *
 * 凭证永远来自宿主**同源服务端**（session = /api/support/session 旧签名；ticket = /api/support/token 短期票据），
 * 嵌入脚本不读也不收任何密钥。不想自动挂载：data-auto="false"，再调 WebcodeSupport.mount({...})。
 *
 * 本文件无副作用；自动挂载与全局变量在 embed.js。
 */

import { createSupportClient, DEFAULT_ORIGIN } from '../client.js';
import { siteSessionCredentials, ticketCredentials } from '../credentials.js';
import { createSupportSession } from '../session.js';
import { createSupportWidget } from './widget.js';
import { normalizeTheme, DEFAULT_THEME } from './theme.js';

/**
 * @param {object} o
 * @param {string} o.app                    产品 app（Worker 租户）
 * @param {'session'|'ticket'|object} [o.auth]  或自带 credentials 提供方（{get, clear, peek}）
 * @param {string} [o.sessionUrl] [o.tokenUrl] [o.origin]
 * @param {'websocket'|'external'|'none'} [o.push]
 * @param {Function} [o.getToken]           旧租户的浏览器 token（限流 / 推送地址）
 * 其余选项原样交给 createSupportWidget（theme / lang / t / title / mode / container / meta / titleBadge ...）
 */
export function mount({
  app,
  auth = 'session',
  sessionUrl,
  tokenUrl,
  origin = DEFAULT_ORIGIN,
  push = 'websocket',
  getToken,
  fetch: f,
  WebSocket: WS,
  sessionOptions = {},
  ...widgetOptions
} = {}) {
  if (!app) throw new TypeError('app required');
  const credentials = typeof auth === 'object' && auth && typeof auth.get === 'function'
    ? auth
    : auth === 'ticket'
      ? ticketCredentials({ app, ...(tokenUrl ? { url: tokenUrl } : {}), ...(f ? { fetch: f } : {}) })
      : siteSessionCredentials({ expectApp: app, ...(sessionUrl ? { url: sessionUrl } : {}), ...(f ? { fetch: f } : {}) });
  const client = createSupportClient({ credentials, origin, getToken, ...(f ? { fetch: f } : {}) });
  const session = createSupportSession({ client, push, ...(WS ? { WebSocket: WS } : {}), ...sessionOptions });
  return createSupportWidget({ session, ...widgetOptions });
}

/** <script data-*> → mount 选项。只认白名单字段，值都再经 theme.js 校验 */
export function optionsFromDataset(ds = {}) {
  const theme = normalizeTheme({
    primary: ds.primary,
    primaryDark: ds.primaryDark,
    fontFamily: ds.font,
    radius: ds.radius,
    icon: ds.icon,
    colorScheme: ds.colorScheme,
  }, DEFAULT_THEME);
  const o = { app: ds.app, theme };
  if (ds.auth === 'ticket' || ds.auth === 'session') o.auth = ds.auth;
  if (ds.sessionUrl) o.sessionUrl = ds.sessionUrl;
  if (ds.tokenUrl) o.tokenUrl = ds.tokenUrl;
  if (ds.origin && /^https:\/\/|^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(ds.origin)) o.origin = ds.origin;
  if (ds.push === 'websocket' || ds.push === 'none') o.push = ds.push;
  if (ds.lang) o.lang = ds.lang;
  if (ds.title) o.title = ds.title;
  if (ds.position === 'bottom-left' || ds.position === 'bottom-right') o.position = ds.position;
  if (ds.mode === 'inline' || ds.mode === 'floating') o.mode = ds.mode;
  if (['default', 'compact', 'actions', 'none'].includes(ds.header)) o.header = { variant: ds.header };
  if (ds.draggable === 'false') o.draggable = false;
  else if (ds.dragPersist === 'true') o.draggable = { persist: true };
  if (ds.subtitle) o.subtitle = ds.subtitle;
  if (ds.titleBadge === 'true') o.titleBadge = true;
  if (ds.attachments === 'false') o.attachments = false;
  if (ds.open === 'true') o.open = true;
  if (ds.zIndex) o.zIndex = Number(ds.zIndex);
  return o;
}
