/**
 * 与 Widget 无关的「拖动把手」：pointer events + pointer capture，鼠标 / 触摸 / 笔统一。
 *
 *   const detach = attachDragHandle(handleEl, {
 *     onMove({ dx, dy, x, y, event }) {},   // dx/dy：相对按下点的累计位移；x/y：指针 client 坐标
 *     onStart() {}, onEnd({ moved, canceled }) {},
 *     ignore: 'button,a,input',             // 额外不触发拖动的选择器（默认已含交互元素）
 *   });
 *
 * - 按在按钮 / 链接 / 输入 / [data-no-drag] 上（含宿主 shadow 内的这类元素，经 composedPath 判断）不拖动
 * - 位移超过 threshold 才算拖动；pointercancel / lostpointercapture 都会收尾，不会残留拖动状态
 * - 不读写任何定位：由调用方在 onMove 里决定怎么摆（所以 inline 宿主可自行接到自己的定位逻辑）
 */

export const DRAG_IGNORE = 'button,a,input,textarea,select,label,summary,[contenteditable],[role="button"],[data-no-drag]';

export function attachDragHandle(handle, { onStart, onMove, onEnd, ignore, threshold = 3, button = 0 } = {}) {
  if (!handle?.addEventListener) throw new TypeError('handle element required');
  const selector = ignore ? `${DRAG_IGNORE},${ignore}` : DRAG_IGNORE;
  let drag = null; // {id, sx, sy, active}

  const blocked = (ev) => {
    const path = typeof ev.composedPath === 'function' ? ev.composedPath() : [ev.target];
    for (const n of path) {
      if (n === handle) break;
      if (n?.nodeType === 1 && n.matches?.(selector)) return true;
    }
    return false;
  };

  function finish(ev, canceled) {
    if (!drag) return;
    const d = drag;
    drag = null;
    try { if (handle.hasPointerCapture?.(d.id)) handle.releasePointerCapture(d.id); } catch { /* 已释放 */ }
    if (d.active) { try { onEnd?.({ moved: true, canceled, event: ev }); } catch { /* 宿主回调出错不影响 */ } }
  }

  function down(ev) {
    if (drag || ev.isPrimary === false) return;
    if (ev.pointerType === 'mouse' && ev.button !== button) return;
    if (blocked(ev)) return;
    drag = { id: ev.pointerId, sx: ev.clientX, sy: ev.clientY, active: false };
    try { handle.setPointerCapture(ev.pointerId); } catch { /* 合成事件可能没有活动指针 */ }
  }
  function move(ev) {
    if (!drag || ev.pointerId !== drag.id) return;
    const dx = ev.clientX - drag.sx;
    const dy = ev.clientY - drag.sy;
    if (!drag.active) {
      if (Math.hypot(dx, dy) < threshold) return;
      drag.active = true;
      try { onStart?.({ event: ev }); } catch { /* ignore */ }
    }
    ev.preventDefault?.();
    try { onMove?.({ dx, dy, x: ev.clientX, y: ev.clientY, event: ev }); } catch { /* ignore */ }
  }
  const up = (ev) => { if (drag && ev.pointerId === drag.id) finish(ev, false); };
  const cancel = (ev) => { if (drag && ev.pointerId === drag.id) finish(ev, true); };
  const lost = (ev) => { if (drag && ev.pointerId === drag.id) finish(ev, true); };

  handle.addEventListener('pointerdown', down);
  handle.addEventListener('pointermove', move);
  handle.addEventListener('pointerup', up);
  handle.addEventListener('pointercancel', cancel);
  handle.addEventListener('lostpointercapture', lost);
  return function detach() {
    finish({}, true);
    handle.removeEventListener('pointerdown', down);
    handle.removeEventListener('pointermove', move);
    handle.removeEventListener('pointerup', up);
    handle.removeEventListener('pointercancel', cancel);
    handle.removeEventListener('lostpointercapture', lost);
  };
}
