/**
 * 框架无关的客服 Widget（原生 DOM + Shadow DOM）。一个 session，一个 Widget：
 *
 *   floating  右下角启动按钮 + 弹出面板（网站）。收起时 session.setActive(false) 只查未读，
 *             展开才 poll（服务端「拉过就算已读」）。
 *   inline    直接铺满 container（桌面端 WebView 的客服页、官网 /contact）。始终展开。
 *
 * 不变式：
 *   - 用户/客服正文一律 textContent，绝不进 innerHTML（innerHTML 只用于本文件内的常量图标）。
 *   - 所有状态来自 session.store；Widget 本身只持有「纯界面」状态（展开、点踩原因草稿、提示条）。
 *   - 主题只经 theme.js 校验后写 CSS 变量；切主题/明暗不重建 DOM、不打断会话。
 */

import { canRate } from '../store.js';
import { FEEDBACK_REASONS, MAX_TEXT_LEN, MAX_FILES, SUPPORT_MODES, MESSAGE_EVENTS, FEEDBACK_COMMENT_MAX } from '../protocol.js';
import { createTranslator, errorMessageKey } from '../i18n.js';
import { titleWithUnread } from '../adapters/titleBadge.js';
import { normalizeTheme, themeCss, documentPrefersDark, BUILTIN_ICONS } from './theme.js';
import { BASE_CSS, ICONS } from './styles.js';
import { attachDragHandle } from './drag.js';

const RTL = /^(ar|he|fa|ur|ps|sd|ug|yi|ckb|dv)\b/i;
const IMAGE_KEY = /\.(png|jpe?g|gif|webp)$/i;
const VIDEO_KEY = /\.(webm|mp4)$/i;
const HEADER_VARIANTS = ['default', 'compact', 'actions', 'none'];
export const WIDGET_VERSION = '0.1.6';
const DEFAULT_DRAG_KEY = 'webcode-support:panel-position';
const HANDOFF_PLACES = ['header', 'footer', 'none'];
const DEFAULT_MAX_IMAGE_BYTES = 2 * 1024 * 1024; // 与服务端 worker/src/files.js 一致
const DEFAULT_MAX_VIDEO_BYTES = 4 * 1024 * 1024;
export const WIDGET_FEATURES = Object.freeze(['slots', 'header', 'headerVariant', 'aboveCompose', 'composeToolbar', 'toggleMode', 'footerBar', 'aboveInputPreview', 'tray', 'addFiles', 'addFilesResult', 'typedQuota', 'setSubtitle', 'paste', 'sizeLimits', 'draggable', 'dragHandle']);
const DEFAULT_ACCEPT = 'image/png,image/jpeg,image/gif,image/webp';

/**
 * attachments: false | true | 策略对象（布尔旧签名保持不变）
 *   accept        input accept 同语法：'image/*,video/webm,.png'；选中文件在客户端按它过滤
 *   maxFiles      单条消息最多附件数（<= MAX_FILES，服务端上限）
 *   reserved      宿主托盘已占用的名额（number | () => number），与 Widget 内选中的文件合计不超 maxFiles
 *   beforeUpload  (file, ctx) => void | true | false | Blob | Promise。选中时调用：undefined/true 接受原文件；
 *                 false（或返回其它非 Blob 值 / 抛错）拒绝，统一提示 errorFileRejected，不暴露回调的错误信息；
 *                 返回 Blob/File 则用它替换原文件上传（如去 EXIF 重绘），类型须满足 accept
 */
/**
 * 宿主插槽：Node（被追加进 Widget 提供的容器）或 (container, ctx) => void | Node | cleanup。
 * 函数形式拿到的是 Widget 专用容器（<div data-slot>），宿主在里面自行挂载（如 React createRoot(container)），
 * 返回 Node 则追加，返回函数则作为 destroy 时的清理。Widget 不碰宿主节点的内部、不用 innerHTML / eval。
 * @typedef {Node | ((container: HTMLElement, ctx: SlotContext) => (void | Node | (() => void)))} SupportSlot
 * @typedef {{ widget: object, shadowRoot: ShadowRoot, open(): void, close(): void, setDraft(text: string, o?: {focus?: boolean}): void }} SlotContext
 * @typedef {{ aboveList?: SupportSlot, aboveCompose?: SupportSlot, composeStart?: SupportSlot }} SupportSlots
 *   aboveList：头部与消息列表之间；
 *   aboveCompose（0.1.4）：消息列表与输入框之间的固定区（截图/录像缩略图、录屏状态条）——占自己的高度，消息列表相应缩小，不覆盖滚动区；
 *   composeStart：输入框**下方工具行左侧**（0.1.4 起；附件按钮之前），与附件按钮、右侧发送按钮同一行同一高度
 * @typedef {{ start?: SupportSlot, end?: SupportSlot, variant?: 'default' | 'compact' | 'actions' | 'none' }} SupportHeader
 *   start：标题之前；end：模式按钮与关闭按钮之间；
 *   variant（0.1.4）：default 完整头部（标题 + 模式 + 转人工）；compact 只留一行「模式文字 + 转人工/返回 AI + 槽位 + 关闭」，标题仅作读屏名称；
 *   actions 宿主已有自己的标题与在线条：只留右对齐的转人工/返回 AI（及宿主槽位、关闭）；无任何可见内容时整条隐藏；
 *   none 完全不显示头部（宿主自己画标题条；此时用 widget.toggleMode() 触发转人工 / 返回 AI）。标题 / 模式文字始终保留给读屏
 * 0.1.5 另有：slots.aboveInputPreview（composer 边框**内**、textarea 上方，与内置待发缩略图同区）、slots.footer（底部状态条内、转人工按钮之前，放宿主状态/动作）；
 *   header.handoff: 'header' | 'footer' | 'none'（转人工按钮位置，默认 footer；variant compact/actions 默认 header，none 默认 none）；
 *   subtitle（标题下小字）；attachments.maxImageBytes / maxVideoBytes（默认 2MB / 4MB，与服务端一致）；widget.addFiles(files)。
 * 另有 onClose(): 点关闭按钮 / 浮动模式按 Esc 时调用。传了 onClose，inline 模式也会显示关闭按钮（默认 inline 不显示）。
 */

function normalizeAttachments(a) {
  if (a === false) return null;
  const p = a && typeof a === 'object' ? a : {};
  if (p.enabled === false) return null;
  const max = Number(p.maxFiles);
  const pos = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Math.floor(Number(v)) : d);
  return {
    maxImages: p.maxImages == null ? null : Math.min(MAX_FILES, pos(p.maxImages, MAX_FILES)),
    maxVideos: p.maxVideos == null ? null : Math.min(MAX_FILES, pos(p.maxVideos, MAX_FILES)),
    maxImageBytes: pos(p.maxImageBytes, DEFAULT_MAX_IMAGE_BYTES),
    maxVideoBytes: pos(p.maxVideoBytes, DEFAULT_MAX_VIDEO_BYTES),
    accept: typeof p.accept === 'string' && p.accept.trim() ? p.accept.trim() : DEFAULT_ACCEPT,
    maxFiles: Number.isFinite(max) && max >= 1 ? Math.min(MAX_FILES, Math.floor(max)) : MAX_FILES,
    reserved: p.reserved ?? 0,
    beforeUpload: typeof p.beforeUpload === 'function' ? p.beforeUpload : null,
  };
}

/** 服务端 at：毫秒或秒的 epoch；过小 / 非法不显示。今天只显示 HH:mm，更早带日期 */
function formatTime(at) {
  const n = Number(at);
  if (!Number.isFinite(n) || n < 1e9) return '';
  const d = new Date(n < 1e12 ? n * 1000 : n);
  const now = new Date();
  const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  return d.toDateString() === now.toDateString() ? hm : `${d.getMonth() + 1}/${d.getDate()} ${hm}`;
}

const isVideoFile = (f) => /^video\//i.test(f?.type || '') || VIDEO_KEY.test(f?.name || '');

function matchesAccept(file, accept) {
  const name = String(file?.name || '').toLowerCase();
  const type = String(file?.type || '').toLowerCase();
  return accept.split(',').map((x) => x.trim().toLowerCase()).filter(Boolean).some((rule) => {
    if (rule.startsWith('.')) return name.endsWith(rule);
    if (rule.endsWith('/*')) return type.startsWith(rule.slice(0, -1));
    return type === rule;
  });
}

export function createSupportWidget({
  session,
  container,
  mode = 'floating',
  position = 'bottom-right',
  theme: themeInput,
  lang = globalThis.navigator?.language || 'en',
  t: lookup,
  title,
  subtitle,
  meta,
  attachments: attachmentsInput = true,
  slots,
  header,
  onClose,
  draggable = true,
  titleBadge = false,
  zIndex,
  open: initiallyOpen = false,
  ownsSession = true,
  onOpenChange = () => {},
  onUnreadChange = () => {},
  document: doc = globalThis.document,
  setTimeout: st = globalThis.setTimeout.bind(globalThis),
  clearTimeout: ct = globalThis.clearTimeout.bind(globalThis),
} = {}) {
  if (!session?.store) throw new TypeError('session required');
  if (!doc) throw new TypeError('document required');
  const store = session.store;
  const inline = mode === 'inline';
  let theme = normalizeTheme(themeInput);
  let t = createTranslator(lookup, lang);
  let isOpen = inline || initiallyOpen === true;
  let destroyed = false;
  const policy = normalizeAttachments(attachmentsInput);
  const attachments = policy !== null;
  let newCount = 0; // 不在底部时到达的新消息数

  // 纯界面状态
  let notice = null; // {key, vars}
  let reasonFor = null; // msgId
  let reasonDraft = { reason: null, comment: '' };
  let modeBusy = false;
  let chosenFiles = [];
  let uploading = false;
  let lastUnread = -1;
  let typingTimer = null;
  let renderQueued = false;
  const fileCache = new Map(); // key → Promise<url|null>
  const objectUrls = [];
  const rows = new Map(); // key → {sig, el}

  /* ------------------------------------------------------------ DOM */

  const el = (tag, props = {}, ...kids) => {
    const n = doc.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'icon') n.innerHTML = ICONS[v]; // 仅常量图标
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else if (k in n && typeof v !== 'string') n[k] = v;
      else n.setAttribute(k, v === true ? '' : String(v));
    }
    for (const c of kids.flat()) if (c != null && c !== false) n.append(c);
    return n;
  };

  const variant = HEADER_VARIANTS.includes(header?.variant) ? header.variant : 'default';
  const handoffAt = HANDOFF_PLACES.includes(header?.handoff) ? header.handoff
    : variant === 'none' ? 'none' : variant === 'default' ? 'footer' : 'header';
  const host = el('webcode-support-widget', { 'data-mode': inline ? 'inline' : 'floating', 'data-position': position, 'data-header': variant });
  const shadow = host.attachShadow({ mode: 'open' });
  const themeStyle = el('style');
  const baseStyle = el('style', { text: BASE_CSS });

  const badge = el('span', { class: 'badge', hidden: true, 'aria-hidden': 'true' });
  const launcherIcon = el('span', { class: 'licon' });
  const launcher = el('button', { class: 'launcher', type: 'button', onclick: () => toggle() }, launcherIcon, badge);

  const titleEl = el('span', { class: 'name' });
  const modeEl = el('span', { class: 'mode' });
  const subEl = el('span', { class: 'sub' });
  const modeIcon = el('span', { class: 'micon', 'aria-hidden': 'true' });
  const modeText = el('span', { class: 'mtext' });
  const modeBtn = el('button', { class: 'modebtn', type: 'button', onclick: onModeClick }, modeIcon, modeText);
  const closeBtn = el('button', { class: 'close', type: 'button', icon: 'close', onclick: () => requestClose() });
  // 插槽容器只在宿主启用对应选项时才创建：不启用 = DOM / 布局与 0.1.2 完全一致
  const slotBox = (spec, name, cls) => (spec ? el('div', { class: cls, 'data-slot': name }) : null);
  const headStart = slotBox(header?.start, 'header-start', 'slot slot-head');
  const headEnd = slotBox(header?.end, 'header-end', 'slot slot-head');
  const aboveList = slotBox(slots?.aboveList, 'above-list', 'slot slot-above');
  const aboveCompose = slotBox(slots?.aboveCompose, 'above-compose', 'slot slot-compose-above');
  const aboveInput = slotBox(slots?.aboveInputPreview, 'above-input-preview', 'slot slot-preview');
  const footerSlot = slotBox(slots?.footer, 'footer', 'slot slot-footer');
  const composeStart = slotBox(slots?.composeStart, 'compose-start', 'slot slot-compose');
  const head = el('div', { class: 'head' }, headStart,
    el('div', { class: 'title' }, titleEl, subEl, handoffAt === 'header' ? modeEl : null),
    handoffAt === 'header' ? modeBtn : null, headEnd, closeBtn);

  const list = el('div', { class: 'list', role: 'log', 'aria-live': 'polite', onscroll: onListScroll });
  const newBtn = el('button', { class: 'newmsg', type: 'button', hidden: true, onclick: () => jumpToBottom() });
  const emptyEl = el('div', { class: 'empty' });
  const typingText = el('span');
  const typingEl = el('div', { class: 'typing', hidden: true, 'aria-live': 'polite' }, el('span', { class: 'dots' }, el('i'), el('i'), el('i')), typingText);
  const errorEl = el('div', { class: 'error', hidden: true, role: 'alert' });
  const chosenEl = el('div', { class: 'chosen sr', hidden: true, role: 'status' });

  const tray = el('div', { class: 'tray', hidden: true });
  const input = el('textarea', { rows: '2', maxlength: String(MAX_TEXT_LEN), onkeydown: onKey, oninput: () => { autosize(); updateSend(); }, onpaste: onPaste });
  const fileInput = el('input', { type: 'file', accept: policy?.accept || DEFAULT_ACCEPT, multiple: true, hidden: true, onchange: onFiles });
  const attachBtn = el('button', { class: 'iconbtn', type: 'button', icon: 'attach', onclick: () => fileInput.click() });
  const sendBtn = el('button', { class: 'sendbtn', type: 'submit', icon: 'send' });
  // 一个 composer：上面输入区，下面一条工具行（左：宿主槽位 + 附件；右：发送），按钮同行同高
  const tools = el('div', { class: 'tools' }, el('div', { class: 'tools-start' }, composeStart, attachments ? [attachBtn, fileInput] : null), sendBtn);
  // 整个输入区是 **一个带边框的框**（.field）：宿主预览槽 / 待发缩略图 → textarea → 工具行（左附件/截图/录像，右发送）
  const field = el('div', { class: 'field' }, aboveInput, tray, input, tools);
  const form = el('form', { class: 'compose', onsubmit: onSubmit }, field);
  // 底部状态条：AI / 人工状态 + 宿主状态 + 转人工 / 返回 AI（细的一行，在列表与输入框之间）
  const handoffBar = handoffAt === 'footer' || footerSlot
    ? el('div', { class: 'handoff', hidden: true }, handoffAt === 'footer' ? modeEl : null, footerSlot, handoffAt === 'footer' ? modeBtn : null)
    : null;

  // list 与「新消息」提示同处 stage：提示浮在 stage 底部，不再靠负 margin 压到下面的元素上
  const stage = el('div', { class: 'stage' }, list, newBtn);
  const panel = el('div', { class: 'panel', role: 'dialog', 'aria-modal': 'false', hidden: !isOpen }, head, aboveList, stage, typingEl, errorEl, aboveCompose, handoffBar, chosenEl, form);
  const root = el('div', { class: 'root' }, panel, launcher);
  shadow.append(themeStyle, baseStyle, root);
  if (zIndex != null && Number.isFinite(Number(zIndex))) root.style.setProperty('--wsu-z', String(Math.trunc(Number(zIndex))));

  /* ------------------------------------------------------------ 主题 */

  let schemeObserver = null;
  function applyTheme() {
    themeStyle.textContent = themeCss(theme);
    launcherIcon.replaceChildren();
    if (BUILTIN_ICONS.includes(theme.icon)) launcherIcon.innerHTML = ICONS[theme.icon];
    else launcherIcon.append(el('img', { src: theme.icon, alt: '' }));
    applyScheme();
  }
  function applyScheme() {
    if (schemeObserver) { schemeObserver.disconnect(); schemeObserver = null; }
    if (theme.colorScheme !== 'document') {
      host.setAttribute('data-scheme', theme.colorScheme);
      return;
    }
    const sync = () => host.setAttribute('data-scheme', documentPrefersDark(doc) ? 'dark' : 'light');
    sync();
    const MO = doc.defaultView?.MutationObserver;
    if (MO) {
      schemeObserver = new MO(sync);
      schemeObserver.observe(doc.documentElement, { attributes: true, attributeFilter: ['class', 'data-theme', 'data-color-scheme', 'style'] });
    }
  }

  function applyLang() {
    host.setAttribute('lang', lang);
    host.setAttribute('dir', RTL.test(lang) ? 'rtl' : 'ltr');
    titleEl.textContent = title || t('title');
    subEl.textContent = subtitle || '';
    subEl.hidden = !subtitle;
    launcher.setAttribute('aria-label', t('open'));
    closeBtn.setAttribute('aria-label', t('close'));
    attachBtn.setAttribute('aria-label', t('attach'));
    attachBtn.title = t('attach');
    sendBtn.setAttribute('aria-label', t('send'));
    input.placeholder = t('placeholder');
    emptyEl.textContent = t('empty');
    panel.setAttribute('aria-label', title || t('title'));
    rows.clear();
    list.replaceChildren();
  }

  /* ------------------------------------------------------------ 渲染 */

  function queueRender() {
    if (renderQueued || destroyed) return;
    renderQueued = true;
    Promise.resolve().then(() => { renderQueued = false; if (!destroyed) render(); });
  }

  function render() {
    const s = store.getState();

    // 未读
    const unread = isOpen ? 0 : s.unread;
    badge.hidden = unread <= 0;
    badge.textContent = unread > 99 ? '99+' : String(unread);
    launcher.setAttribute('aria-label', unread > 0 ? `${t('open')} · ${t('unread', { count: unread })}` : t('open'));
    if (unread !== lastUnread) {
      lastUnread = unread;
      if (titleBadge) doc.title = titleWithUnread(doc.title, unread);
      onUnreadChange(unread);
    }
    if (!isOpen) return;

    // 头部：模式 + 转人工/返回 AI
    modeEl.textContent = t(s.supportMode === SUPPORT_MODES.HUMAN ? 'modeHuman' : s.supportMode === SUPPORT_MODES.HUMAN_REQUESTED ? 'modeHumanRequested' : 'modeAi');
    const canHuman = session.canRequestHuman();
    const canAi = session.canResumeAi();
    modeBtn.hidden = !s.loaded || (!canHuman && !canAi);
    modeText.textContent = canAi ? t('toAi') : t('toHuman');
    modeIcon.innerHTML = ICONS[canAi ? 'chat' : 'person'];
    modeBtn.disabled = modeBusy;
    modeBtn.setAttribute('aria-busy', String(modeBusy));
    if (handoffBar) handoffBar.hidden = !s.loaded;
    // actions 变体：没有任何可见内容（无会话按钮、无宿主槽位、无关闭）时整条隐藏，不留空白条
    head.hidden = variant === 'none' || (variant === 'actions' && (handoffAt !== 'header' || modeBtn.hidden) && !headStart && !headEnd && inline && !onClose);

    renderList(s);

    // typing：过期时刻再渲染一次，不需要轮询状态
    const actor = store.activeTyping();
    typingEl.hidden = !actor;
    typingText.textContent = actor ? t(actor === 'human' ? 'typingHuman' : 'typingAi') : '';
    if (typingTimer) { ct(typingTimer); typingTimer = null; }
    if (actor && s.typing) typingTimer = st(() => { typingTimer = null; queueRender(); }, Math.max(50, s.typing.expiresAt - Date.now() + 20));

    // 提示条：本地动作错误优先；首次加载失败给通用提示
    const err = notice ? t(notice.key, notice.vars) : !s.loaded && s.error ? t(errorMessageKey(s.error)) : '';
    errorEl.hidden = !err;
    errorEl.textContent = err;

    newBtn.hidden = newCount <= 0;
    newBtn.textContent = newCount > 0 ? t('newMessages', { count: newCount }) : '';
    chosenEl.hidden = chosenFiles.length === 0;
    chosenEl.textContent = chosenFiles.length ? t('filesChosen', { count: chosenFiles.length }) : '';
    renderTray();
    updateSend();
    attachBtn.disabled = uploading || (policy ? chosenFiles.length >= slotsLeft() : false);
  }

  function updateSend() {
    sendBtn.disabled = uploading || (!input.value.trim() && chosenFiles.length === 0);
  }

  /* 待发附件托盘：贴在输入框内部顶上，缩略图 + 删除；视频用 <video muted> 首帧 */
  const previewUrls = new Map(); // File → blob: url
  let trayFiles = null;
  let trayBusy = false;
  function previewOf(f) {
    if (!previewUrls.has(f)) {
      let u = null;
      try { u = (doc.defaultView?.URL || globalThis.URL).createObjectURL(f); } catch { /* jsdom 等无 createObjectURL */ }
      previewUrls.set(f, u);
    }
    return previewUrls.get(f);
  }
  function dropPreviews(keep = []) {
    for (const [f, u] of [...previewUrls]) {
      if (keep.includes(f)) continue;
      if (u) { try { (doc.defaultView?.URL || globalThis.URL).revokeObjectURL(u); } catch { /* ignore */ } }
      previewUrls.delete(f);
    }
  }
  function renderTray() {
    if (trayFiles === chosenFiles && trayBusy === uploading) return;
    trayFiles = chosenFiles;
    trayBusy = uploading;
    dropPreviews(chosenFiles);
    tray.hidden = chosenFiles.length === 0;
    tray.replaceChildren(...chosenFiles.map((f, i) => {
      const url = previewOf(f);
      const media = isVideoFile(f)
        ? el('video', { muted: true, preload: 'metadata', playsinline: true, 'aria-label': f.name || t('attachment'), ...(url ? { src: url } : {}) })
        : el('img', { alt: f.name || t('attachment'), ...(url ? { src: url } : {}) });
      return el('span', { class: 'thumb', 'data-index': String(i) }, media,
        uploading ? el('em', { text: t('uploading') }) : null,
        el('button', { type: 'button', icon: 'close', disabled: uploading, 'aria-label': t('remove'), title: t('remove'), onclick: () => removeChosen(f) }));
    }));
  }
  function removeChosen(f) {
    chosenFiles = chosenFiles.filter((x) => x !== f);
    if (!chosenFiles.length) fileInput.value = '';
    queueRender();
  }

  function renderList(s) {
    const nearBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 48;
    const items = [];
    for (const m of s.messages) items.push(messageItem(s, m));
    for (const p of s.pending) items.push(pendingItem(p));
    const keep = new Set(items.map((i) => i.key));
    for (const k of [...rows.keys()]) if (!keep.has(k)) { rows.get(k).el.remove(); rows.delete(k); }

    if (!items.length) {
      if (emptyEl.parentNode !== list) list.replaceChildren(emptyEl);
      return;
    }
    if (emptyEl.parentNode === list) emptyEl.remove();
    let added = false;
    let prev = null;
    const hadRows = rows.size > 0;
    let fresh = 0;
    for (const item of items) {
      let r = rows.get(item.key);
      if (!r || r.sig !== item.sig) {
        const next = item.build();
        if (!r && hadRows && item.incoming) fresh++;
        if (r) r.el.replaceWith(next);
        r = { sig: item.sig, el: next };
        rows.set(item.key, r);
        added = true;
      }
      const want = prev ? prev.nextSibling : list.firstChild;
      if (want !== r.el) list.insertBefore(r.el, want);
      prev = r.el;
    }
    if (added && nearBottom) { list.scrollTop = list.scrollHeight; newCount = 0; } else if (fresh) newCount += fresh;
  }

  function onListScroll() {
    if (newCount && list.scrollHeight - list.scrollTop - list.clientHeight < 48) { newCount = 0; queueRender(); }
  }
  function jumpToBottom() {
    list.scrollTop = list.scrollHeight;
    newCount = 0;
    queueRender();
  }

  function messageItem(s, m) {
    const rateable = canRate(s, m);
    const busy = s.feedbackBusy[m.id] === true;
    const open = rateable && reasonFor === m.id;
    const sig = JSON.stringify([m.kind, m.event, m.text, m.files, rateable, m.feedback, busy, open, open ? reasonDraft.reason : null]);
    return { key: `m${m.id}`, incoming: m.kind !== 'user', sig, build: () => buildMessage(m, { rateable, busy, open }) };
  }

  function buildMessage(m, { rateable, busy, open }) {
    if (m.kind === 'user' && (m.event === MESSAGE_EVENTS.REQUEST_HUMAN || m.event === MESSAGE_EVENTS.RESUME_AI)) {
      return el('div', { class: 'divider', 'data-id': m.id, text: t(m.event === MESSAGE_EVENTS.REQUEST_HUMAN ? 'eventRequestHuman' : 'eventResumeAi') });
    }
    if (m.kind === 'system') return el('div', { class: 'divider', 'data-id': m.id, text: m.text || t('eventHumanAck') });
    const who = m.kind === 'ai' ? t('roleAi') : m.kind === 'human' ? t('roleHuman') : null;
    const time = formatTime(m.at);
    const row = el('div', { class: `row ${m.kind}`, 'data-id': m.id },
      who ? el('div', { class: 'byline' }, el('span', { class: 'who', text: who }), time ? el('time', { class: 'time', text: time }) : null) : null,
      el('div', { class: m.text ? 'bubble' : 'bubble media', text: m.text }, m.files.length ? buildFiles(m.files) : null),
      !who && time ? el('div', { class: 'byline after' }, el('time', { class: 'time', text: time })) : null);
    if (rateable) {
      row.append(buildRate(m, busy));
      if (open) row.append(buildReasons(m, busy));
    }
    return row;
  }

  function buildFiles(keys) {
    const box = el('div', { class: 'files' });
    for (const key of keys) {
      const isImg = IMAGE_KEY.test(key);
      const isVideo = !isImg && VIDEO_KEY.test(key);
      const node = isImg ? el('img', { alt: t('attachment'), loading: 'lazy' })
        : isVideo ? el('video', { controls: true, preload: 'metadata', playsinline: true, 'aria-label': t('attachment') })
          : el('a', { text: t('attachment'), target: '_blank', rel: 'noopener noreferrer' });
      box.append(node);
      resolveFile(key).then((url) => {
        if (!url) return;
        if (isImg || isVideo) node.src = url;
        else node.href = url;
      });
    }
    return box;
  }

  /** 旧签名能直接拼 URL；票据不进 URL → fetch 成 blob: */
  function resolveFile(key) {
    if (!fileCache.has(key)) {
      fileCache.set(key, (async () => {
        try {
          const direct = await session.client.fileUrl(key);
          if (direct) return direct;
          const blob = await session.client.fetchFile(key);
          const URL_ = doc.defaultView?.URL || globalThis.URL;
          if (!URL_?.createObjectURL) return null;
          const u = URL_.createObjectURL(blob);
          objectUrls.push(u);
          return u;
        } catch {
          fileCache.delete(key);
          return null;
        }
      })());
    }
    return fileCache.get(key);
  }

  function buildRate(m, busy) {
    const r = m.feedback?.rating || null;
    const mk = (rating) => el('button', {
      type: 'button', icon: rating, disabled: busy, 'aria-pressed': String(r === rating),
      'aria-label': t(rating === 'up' ? 'rateUp' : 'rateDown'), title: t(rating === 'up' ? 'rateUp' : 'rateDown'),
      'data-rate': rating, onclick: () => onRate(m, rating),
    });
    return el('div', { class: 'rate' }, mk('up'), mk('down'));
  }

  function buildReasons(m, busy) {
    const chips = FEEDBACK_REASONS.map((reason) => el('button', {
      type: 'button', 'data-reason': reason, 'aria-pressed': String(reasonDraft.reason === reason),
      text: t(`reason_${reason}`), onclick: () => { reasonDraft = { ...reasonDraft, reason }; queueRender(); },
    }));
    const comment = el('textarea', {
      maxlength: String(FEEDBACK_COMMENT_MAX), placeholder: t('commentPlaceholder'),
      oninput: (e) => { reasonDraft.comment = e.target.value; },
    });
    comment.value = reasonDraft.comment;
    return el('div', { class: 'reasons' },
      el('div', { class: 'q', text: t('reasonTitle') }),
      el('div', { class: 'chips' }, chips),
      comment,
      el('div', { class: 'actions' }, el('button', {
        class: 'primary', type: 'button', disabled: busy || !reasonDraft.reason, text: t('submit'),
        'data-action': 'submit-reason', onclick: () => submitReason(m),
      })));
  }

  function pendingItem(p) {
    const sig = JSON.stringify([p.text, p.files?.length || 0, p.state, p.error]);
    return {
      key: `p${p.clientId}`,
      sig,
      build: () => el('div', { class: `row user ${p.state === 'failed' ? 'failed' : 'pending'}`, 'data-client-id': p.clientId },
        el('div', { class: 'bubble', text: p.text }),
        p.state === 'failed'
          ? el('div', { class: 'status err' }, t(errorMessageKey(p.error)),
            el('button', { type: 'button', text: t('retry'), onclick: () => retry(p) }))
          : p.state === 'sending' ? el('div', { class: 'status', text: t('sending') }) : null),
    };
  }

  /* ------------------------------------------------------------ 动作 */

  const say = (key, vars) => { notice = key ? { key, vars } : null; queueRender(); };
  const metaNow = () => (typeof meta === 'function' ? meta() : meta) || undefined;

  async function onSubmit(e) {
    e?.preventDefault?.();
    if (uploading) return;
    const text = input.value.trim();
    if (!text && !chosenFiles.length) return;
    if (text.length > MAX_TEXT_LEN) return say('errorTooLong');
    say(null);
    let files = [];
    if (chosenFiles.length) {
      uploading = true;
      queueRender();
      if (chosenFiles.length > slotsLeft()) {
        uploading = false;
        return say('errorTooManyFiles', { max: policy.maxFiles });
      }
      try {
        files = (await Promise.all(chosenFiles.map((f) => session.upload(f)))).map((r) => r.key);
      } catch (err) {
        uploading = false;
        return say(errorMessageKey(err?.code));
      }
      uploading = false;
      chosenFiles = [];
      fileInput.value = '';
    }
    input.value = '';
    updateSend();
    autosize();
    // 上传成功后即清空本地缩略图；不依赖会话 store 是否发出新的推送。
    queueRender();
    await doSend({ text, files });
  }

  async function doSend(payload) {
    try {
      await session.send({ ...payload, lang, meta: metaNow() });
    } catch (err) {
      if (err?.code !== 'identity_changed') say(errorMessageKey(err?.code));
    }
  }

  function retry(p) {
    store.dropPending(p.clientId);
    doSend({ text: p.text, files: p.files || [] });
  }

  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      onSubmit();
    } else if (e.key === 'Escape' && !inline) {
      requestClose();
    }
  }

  function autosize() {
    input.style.height = 'auto';
    if (input.scrollHeight) input.style.height = `${Math.min(120, input.scrollHeight)}px`;
  }

  /** 还能再加几个：maxFiles − 宿主托盘已占（reserved）；不含已选 */
  function reservedNow() {
    const r = Number(typeof policy.reserved === 'function' ? policy.reserved() : policy.reserved);
    return Number.isFinite(r) && r > 0 ? Math.floor(r) : 0;
  }
  function slotsLeft() { return Math.max(0, policy.maxFiles - reservedNow()); }

  async function onFiles() {
    const picked = [...(fileInput.files || [])];
    fileInput.value = '';
    return addPicked(picked);
  }

  /** 直接 Ctrl/Cmd+V 贴图：只拦截符合 accept 的图片 / 视频文件，纯文本照常粘贴 */
  function onPaste(e) {
    if (!policy) return;
    const files = [...(e.clipboardData?.files || [])].filter((f) => matchesAccept(f, policy.accept));
    if (!files.length) return;
    e.preventDefault();
    addPicked(files);
  }

  /** 选文件 / 粘贴 / 宿主 addFiles 共用：类型 → beforeUpload → 大小（图 2MB、视频 4MB，同服务端）→ 名额 */
  async function addPicked(picked) {
    const result = { accepted: [], rejected: [] };
    if (!picked.length || !policy) return result;
    let msgKey = null;
    let msgMax = policy.maxFiles;
    const accepted = result.accepted;
    const reject = (file, reason, key) => { result.rejected.push({ file, reason }); msgKey ||= key; };
    for (const f of picked) {
      if (!matchesAccept(f, policy.accept)) { reject(f, 'type', 'errorFileType'); continue; }
      let out = f;
      if (policy.beforeUpload) {
        let verdict;
        try {
          // files：当前已选 + 本批已接受的文件（宿主可据此按类型做名额判断）
          verdict = await policy.beforeUpload(f, { chosen: chosenFiles.length + accepted.length, reserved: reservedNow(), max: policy.maxFiles, files: [...chosenFiles, ...accepted] });
        } catch { verdict = false; } // 回调抛错的 message 不外泄给终端用户
        if (verdict instanceof Blob) {
          // 回调返回处理后的 Blob/File（如去 EXIF 重绘）：改用它上传；类型仍须满足 accept
          if (!matchesAccept(verdict, policy.accept)) { reject(f, 'rejected', 'errorFileRejected'); continue; }
          out = verdict;
        } else if (verdict != null && verdict !== true) { // false / 字符串 / 其它 = 拒绝
          reject(f, 'rejected', 'errorFileRejected');
          continue;
        }
      }
      const video = isVideoFile(out);
      if (out.size > (video ? policy.maxVideoBytes : policy.maxImageBytes)) { reject(f, 'too_large', 'errorTooLarge'); continue; }
      const same = [...chosenFiles, ...accepted].filter((x) => isVideoFile(x) === video).length;
      const typeMax = video ? policy.maxVideos : policy.maxImages;
      if (chosenFiles.length + accepted.length >= slotsLeft()) { reject(f, 'too_many', 'errorTooManyFiles'); msgKey = 'errorTooManyFiles'; msgMax = policy.maxFiles; continue; }
      if (typeMax != null && same >= typeMax) { reject(f, 'too_many', 'errorTooManyFiles'); msgKey = 'errorTooManyFiles'; msgMax = typeMax; continue; }
      accepted.push(out);
    }
    if (accepted.length) chosenFiles = [...chosenFiles, ...accepted];
    say(msgKey, msgKey === 'errorTooManyFiles' ? { max: msgMax } : undefined);
    return result;
  }

  async function onModeClick() {
    if (modeBusy) return;
    modeBusy = true;
    say(null);
    try {
      if (session.canResumeAi()) await session.resumeAi({ lang });
      else await session.requestHuman({ lang });
    } catch (err) {
      say(errorMessageKey(err?.code));
    } finally {
      modeBusy = false;
      queueRender();
    }
  }

  async function onRate(m, rating) {
    const current = m.feedback?.rating || null;
    const next = current === rating ? null : rating;
    say(null);
    try {
      await session.rate(m.id, next);
      if (next === 'down') { reasonFor = m.id; reasonDraft = { reason: null, comment: '' }; } else if (reasonFor === m.id) reasonFor = null;
    } catch (err) {
      say(errorMessageKey(err?.code));
    }
    queueRender();
  }

  async function submitReason(m) {
    if (!reasonDraft.reason) return;
    try {
      await session.rate(m.id, 'down', { reason: reasonDraft.reason, comment: reasonDraft.comment });
      reasonFor = null;
    } catch (err) {
      say(errorMessageKey(err?.code));
    }
    queueRender();
  }

  /* ------------------------------------------------------------ 拖动（仅 floating） */

  // 偏移量 (dx,dy) 相对默认锚点（右下 / 左下角），以 CSS translate 作用在 panel 上，启动按钮不动。
  // want 是用户想要的偏移，applied 是夹进可视区后的实际偏移：视口变大时能回到原位。
  const dragOpts = draggable && typeof draggable === 'object' ? draggable : {};
  const dragEnabled = !inline && draggable !== false && variant !== 'none';
  const dragMargin = Number.isFinite(Number(dragOpts.margin)) ? Math.max(0, Number(dragOpts.margin)) : 8;
  const dragKey = dragOpts.persist === true ? DEFAULT_DRAG_KEY : typeof dragOpts.persist === 'string' && dragOpts.persist ? dragOpts.persist : null;
  const dragStore = () => { try { return dragOpts.storage || doc.defaultView?.localStorage || null; } catch { return null; } };
  let want = { x: 0, y: 0 };
  let applied = { x: 0, y: 0 };
  let dragging = false;
  let dragOrigin = null;
  let detachDrag = null;
  if (dragKey) {
    try {
      const v = JSON.parse(dragStore()?.getItem(dragKey) || 'null');
      if (v && Number.isFinite(v.x) && Number.isFinite(v.y)) want = { x: v.x, y: v.y };
    } catch { /* 存储不可用 / 脏数据 */ }
  }
  function viewportSize() {
    const v = doc.defaultView;
    const de = doc.documentElement;
    return { w: Math.min(de?.clientWidth || Infinity, v?.innerWidth || Infinity), h: Math.min(de?.clientHeight || Infinity, v?.innerHeight || Infinity) };
  }
  function clampOffset(o) {
    if (!isOpen || panel.hidden) return o;
    const r = panel.getBoundingClientRect();
    if (!r.width && !r.height) return o;
    const { w, h } = viewportSize();
    const bl = r.left - applied.x;
    const bt = r.top - applied.y;
    const lo = (a) => dragMargin - a;
    const hi = (a, size, max) => max - dragMargin - (a + size);
    const cl = (v, l, u) => Math.min(Math.max(v, l), Math.max(l, u));
    return { x: Math.round(cl(o.x, lo(bl), hi(bl, r.width, w))), y: Math.round(cl(o.y, lo(bt), hi(bt, r.height, h))) };
  }
  function paintOffset(o) {
    applied = o;
    panel.style.setProperty('--wsu-dx', `${o.x}px`);
    panel.style.setProperty('--wsu-dy', `${o.y}px`);
    host.toggleAttribute('data-moved', o.x !== 0 || o.y !== 0);
  }
  function reclamp() { if (dragEnabled && !dragging) paintOffset(clampOffset(want)); }
  function savePosition() {
    if (!dragKey) return;
    try {
      const s = dragStore();
      if (want.x === 0 && want.y === 0) s?.removeItem(dragKey);
      else s?.setItem(dragKey, JSON.stringify(want));
    } catch { /* 存储不可用不影响拖动 */ }
  }
  function setupDrag() {
    if (!dragEnabled) return;
    host.setAttribute('data-draggable', '');
    detachDrag = attachDragHandle(head, {
      onStart() { dragging = true; dragOrigin = applied; host.setAttribute('data-dragging', ''); },
      onMove({ dx, dy }) { paintOffset(clampOffset({ x: dragOrigin.x + dx, y: dragOrigin.y + dy })); },
      onEnd() { dragging = false; host.removeAttribute('data-dragging'); want = applied; savePosition(); },
    });
    doc.defaultView?.addEventListener('resize', reclamp);
    reclamp();
  }
  function teardownDrag() {
    detachDrag?.();
    doc.defaultView?.removeEventListener('resize', reclamp);
  }

  /* ------------------------------------------------------------ 开关 */

  function setOpen(next) {
    next = inline || next === true;
    if (next === isOpen) return;
    isOpen = next;
    panel.hidden = !isOpen;
    launcher.setAttribute('aria-expanded', String(isOpen));
    session.setActive?.(isOpen);
    if (isOpen) {
      notice = null;
      reclamp();
      st(() => { if (isOpen && !destroyed) { input.focus(); list.scrollTop = list.scrollHeight; } }, 0);
    }
    onOpenChange(isOpen);
    queueRender();
  }
  function requestClose() {
    close();
    try { onClose?.(); } catch { /* 宿主回调出错不影响 Widget */ }
  }
  function open() { setOpen(true); }
  function close() { setOpen(false); }
  function toggle() { setOpen(!isOpen); }

  let lastIdentity = store.getState().identityKey;
  const unsub = store.subscribe((s) => {
    // 身份变了（登录 / 登出 / 切账号）：界面草稿也属于旧账号，一起清掉
    if (s.identityKey !== lastIdentity) {
      lastIdentity = s.identityKey;
      reasonFor = null;
      reasonDraft = { reason: null, comment: '' };
      notice = null;
      chosenFiles = [];
      dropPreviews();
      fileInput.value = '';
      input.value = '';
      for (const u of objectUrls.splice(0)) (doc.defaultView?.URL || globalThis.URL)?.revokeObjectURL?.(u);
      fileCache.clear();
    }
    queueRender();
  });

  applyTheme();
  applyLang();
  setupDrag();
  launcher.setAttribute('aria-expanded', String(isOpen));
  (container || doc.body).append(host);
  reclamp();
  session.setActive?.(isOpen);
  if (ownsSession) session.start();
  render();

  const api = {
    host,
    shadowRoot: shadow,
    session,
    open,
    close,
    toggle,
    isOpen: () => isOpen,
    getTheme: () => theme,
    /** 局部覆盖主题（品牌切换 / 运行时调色）：不重建 DOM、不打断会话 */
    setTheme(partial) {
      theme = normalizeTheme(partial, theme);
      applyTheme();
    },
    setColorScheme(scheme) {
      theme = normalizeTheme({ colorScheme: scheme }, theme);
      applyScheme();
    },
    setLang(nextLang, nextLookup = lookup) {
      lang = nextLang;
      lookup = nextLookup;
      t = createTranslator(lookup, lang);
      applyLang();
      render();
    },
    /** 登录 / 登出 / 切账号 */
    resetIdentity: () => session.resetIdentity(),
    /** 预填输入框（不经 shadowRoot）。focus:true 时若面板收起会先展开。超长文本截到 MAX_TEXT_LEN */
    setDraft(text, { focus = false } = {}) {
      input.value = String(text ?? '').slice(0, MAX_TEXT_LEN);
      autosize();
      updateSend();
      if (focus) { open(); input.focus?.(); }
    },
    getDraft: () => input.value,
    /** 宿主交来的 File/Blob（截图 / 录屏结果）：走与选文件相同的校验与名额，进入输入框内的缩略图托盘 */
    /** 返回 Promise<{accepted: File[], rejected: {file, reason: 'type'|'rejected'|'too_large'|'too_many'}[]}> */
    addFiles: (files) => addPicked([...(files || [])].filter((f) => f && typeof f.size === 'number' && typeof f.type === 'string')),
    getFiles: () => [...chosenFiles],
    /** 动态副标题（如排班 / 在线状态）；空串清除 */
    setSubtitle(text) { subtitle = String(text ?? ''); subEl.textContent = subtitle; subEl.hidden = !subtitle; },
    /** 转人工 / 返回 AI（复用头部按钮的忙状态与错误提示）；当前不可用时返回 false */
    toggleMode: async () => {
      if (modeBusy || !(session.canResumeAi() || session.canRequestHuman())) return false;
      await onModeClick();
      return true;
    },
    /** 面板相对默认锚点的偏移（仅 floating 且 draggable）；收起 / 未拖动为 0 */
    getPosition: () => ({ x: applied.x, y: applied.y, moved: applied.x !== 0 || applied.y !== 0 }),
    /** 程序设置偏移（会夹进可视区）；persist 配置开启时同时保存 */
    setPosition({ x = 0, y = 0 } = {}) {
      if (!dragEnabled) return false;
      want = { x: Number(x) || 0, y: Number(y) || 0 };
      paintOffset(clampOffset(want));
      want = applied;
      savePosition();
      return true;
    },
    /** 回到默认右下 / 左下角并清除已保存位置 */
    resetPosition() {
      if (!dragEnabled) return false;
      want = { x: 0, y: 0 };
      paintOffset(want);
      savePosition();
      return true;
    },
    version: WIDGET_VERSION,
    features: WIDGET_FEATURES,
    destroy() {
      if (destroyed) return;
      destroyed = true;
      unsub();
      if (typingTimer) ct(typingTimer);
      if (schemeObserver) schemeObserver.disconnect();
      teardownDrag();
      if (ownsSession) session.stop();
      for (const c of slotCleanups.splice(0)) { try { c(); } catch { /* ignore */ } }
      dropPreviews();
      for (const u of objectUrls.splice(0)) (doc.defaultView?.URL || globalThis.URL)?.revokeObjectURL?.(u);
      if (titleBadge) doc.title = titleWithUnread(doc.title, 0);
      host.remove();
    },
  };

  if (typeof onClose === 'function') host.setAttribute('data-closable', '');
  const slotCleanups = [];
  const ctx = { widget: api, shadowRoot: shadow, open, close, setDraft: api.setDraft };
  const mountSlot = (spec, box) => {
    if (!spec || !box) return;
    try {
      const out = typeof spec === 'function' ? spec(box, ctx) : spec;
      if (typeof out === 'function') slotCleanups.push(out);
      else if (out && typeof out.nodeType === 'number' && out.parentNode !== box) box.append(out);
    } catch { /* 宿主插槽出错不影响客服主流程 */ }
  };
  mountSlot(header?.start, headStart);
  mountSlot(header?.end, headEnd);
  mountSlot(slots?.aboveList, aboveList);
  mountSlot(slots?.aboveCompose, aboveCompose);
  mountSlot(slots?.aboveInputPreview, aboveInput);
  mountSlot(slots?.footer, footerSlot);
  mountSlot(slots?.composeStart, composeStart);
  return api;
}
