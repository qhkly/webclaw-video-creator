/** Widget 结构样式。颜色/圆角/字体全部来自 theme.js 的 --wsu-* 变量，这里不出现任何品牌值 */

export const ICONS = Object.freeze({
  chat: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.2 3.6c-.5.4-1.3.1-1.3-.6V16A2.5 2.5 0 0 1 4 13.5z" fill="currentColor"/></svg>',
  headset: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a8 8 0 0 0-8 8v5a3 3 0 0 0 3 3h1a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H6v-1a6 6 0 1 1 12 0v1h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h2a1 1 0 0 1-1 1h-3a1 1 0 1 0 0 2h3a3 3 0 0 0 3-3v-7a8 8 0 0 0-8-8z" fill="currentColor"/></svg>',
  help: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 15.5a1.25 1.25 0 1 1 0-2.5 1.25 1.25 0 0 1 0 2.5zm1.3-5.1c-.6.4-.8.6-.8 1.1v.3h-2v-.4c0-1.3.6-2 1.5-2.6.7-.5 1-.8 1-1.4 0-.7-.5-1.2-1.3-1.2-.9 0-1.4.6-1.5 1.4H8.2C8.3 7.6 9.8 6.3 12 6.3c2.1 0 3.5 1.2 3.5 3 0 1.4-.9 2.2-2.2 3.1z" fill="currentColor"/></svg>',
  close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.4 5 12 10.6 17.6 5 19 6.4 13.4 12l5.6 5.6-1.4 1.4-5.6-5.6L6.4 19 5 17.6l5.6-5.6L5 6.4z" fill="currentColor"/></svg>',
  send: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m0 0-6 6m6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  attach: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 11.5-8.6 8.6a5.5 5.5 0 0 1-7.8-7.8l8.9-8.9a3.7 3.7 0 0 1 5.2 5.2l-8.9 8.9a1.8 1.8 0 0 1-2.6-2.6l8.2-8.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  person: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.6" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4.8 20c.6-3.6 3.5-5.6 7.2-5.6s6.6 2 7.2 5.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  up: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 21h3V9H2zm20-11a2 2 0 0 0-2-2h-6.3l1-4.6v-.3c0-.4-.2-.8-.4-1.1L13.2 1 6.6 7.6c-.4.4-.6.9-.6 1.4v10a2 2 0 0 0 2 2h9c.8 0 1.5-.5 1.8-1.2l3-7.1c.1-.2.2-.5.2-.7z" fill="currentColor"/></svg>',
  down: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 3h-3v12h3zM2 14a2 2 0 0 0 2 2h6.3l-1 4.6v.3c0 .4.2.8.4 1.1l1.1 1 6.6-6.6c.4-.4.6-.9.6-1.4V5a2 2 0 0 0-2-2H7c-.8 0-1.5.5-1.8 1.2l-3 7.1c-.1.2-.2.5-.2.7z" fill="currentColor"/></svg>',
});

export const BASE_CSS = `
:host{all:initial;font-family:var(--wsu-font);font-size:14px;line-height:1.5;color:var(--wsu-text);}
:host([data-mode="inline"]){display:block;height:100%;min-height:0;min-width:0;flex:1 1 auto;}
*,*::before,*::after{box-sizing:border-box;}
button,textarea,input{font:inherit;color:inherit;}
button{cursor:pointer;}
button:disabled{cursor:default;opacity:.55;}
:focus-visible{outline:2px solid var(--wsu-primary);outline-offset:2px;}
svg{width:1em;height:1em;display:block;}
.root{position:fixed;z-index:var(--wsu-z,2147483000);bottom:20px;right:20px;display:flex;flex-direction:column;align-items:flex-end;gap:12px;}
:host([data-position="bottom-left"]) .root{right:auto;left:20px;align-items:flex-start;}
:host([data-mode="inline"]) .root{position:static;inset:auto;height:100%;min-height:0;align-items:stretch;gap:0;}
.launcher{position:relative;width:56px;height:56px;border-radius:50%;border:0;background:var(--wsu-primary);color:var(--wsu-on-primary);box-shadow:var(--wsu-shadow);display:grid;place-items:center;font-size:26px;transition:transform .15s;}
.launcher:hover{transform:scale(1.05);}
.launcher img{width:30px;height:30px;object-fit:contain;}
:host([data-mode="inline"]) .launcher{display:none;}
.badge{position:absolute;top:-2px;right:-2px;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:var(--wsu-danger);color:#fff;font-size:12px;font-weight:600;line-height:20px;text-align:center;border:2px solid var(--wsu-bg);}
.badge[hidden]{display:none;}
.panel{width:min(360px,calc(100vw - 32px));height:min(520px,calc(100vh - 110px));height:min(520px,calc(100dvh - 110px));background:var(--wsu-bg);border:1px solid var(--wsu-border);border-radius:var(--wsu-radius);box-shadow:var(--wsu-shadow);display:flex;flex-direction:column;overflow:hidden;min-height:0;}
.panel[hidden]{display:none;}
:host([data-mode="floating"]) .panel{translate:var(--wsu-dx,0px) var(--wsu-dy,0px);}
:host([data-draggable]) .head{cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;}
:host([data-draggable]) .head :where(button,a,input,select,textarea){cursor:pointer;touch-action:manipulation;}
:host([data-dragging]) .head,:host([data-dragging]) .head *{cursor:grabbing;}
:host([data-dragging]) .panel{box-shadow:var(--wsu-shadow),0 8px 28px rgba(0,0,0,.18);}
:host([data-mode="inline"]) .panel{width:100%;height:auto;flex:1 1 auto;box-shadow:none;border-radius:0;border-width:0;}
.head{flex:none;display:flex;align-items:flex-start;gap:10px;padding:12px 14px;background:var(--wsu-surface);color:var(--wsu-text);border-bottom:1px solid var(--wsu-border);}
.head[hidden]{display:none;}
.head .title{flex:1;min-width:0;display:flex;flex-direction:column;}
.head .name{font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.head .sub{margin-top:2px;color:var(--wsu-muted);font-size:12px;font-weight:400;}
.head .sub:empty{display:none;}
.mode{font-size:12px;color:var(--wsu-muted);display:block;font-weight:400;}
.head button{border:0;background:transparent;color:inherit;border-radius:var(--wsu-radius-sm);padding:6px 8px;}
.head button:hover{background:rgba(127,127,127,.16);}
.head .modebtn{align-self:center;}
.head .close{font-size:16px;padding:2px;color:var(--wsu-muted);}
.head .close:hover{color:var(--wsu-text);background:none;}
:host([data-mode="inline"]) .head .close{display:none;}
:host([data-mode="inline"][data-closable]) .head .close{display:block;}
:host([data-header="compact"]) .head{padding:6px 10px;align-items:center;}
:host([data-header="compact"]) .head .name{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);}
:host([data-header="actions"]) .head{align-items:center;padding:6px 10px;border-bottom:0;background:var(--wsu-bg);justify-content:flex-end;}
:host([data-header="actions"]) .head .title{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);flex:none;}
:host([data-header="actions"]) .head .modebtn{margin-inline-start:auto;}
.slot{display:flex;align-items:center;gap:6px;min-width:0;}
.slot:empty{display:none;}
.slot-head{flex:none;}
.slot-above{flex:none;padding:6px 14px;border-bottom:1px solid var(--wsu-border);background:var(--wsu-bg);}
.slot-compose{flex:none;gap:2px;}
.slot-compose :where(button){flex:none;width:30px;height:30px;padding:0;border:0;border-radius:8px;background:transparent;color:var(--wsu-muted);display:inline-grid;place-items:center;font-size:17px;}
.slot-compose :where(button:hover:not(:disabled)){background:var(--wsu-surface);color:var(--wsu-text);}
.slot-compose :where(button[data-state="recording"],button.is-recording){color:var(--wsu-danger);background:rgba(220,38,38,.14);}
.slot-compose :where(svg){width:17px;height:17px;}
.slot-compose-above{flex:none;padding:0 14px 8px;background:var(--wsu-bg);}
.slot-preview{padding:0 0 2px;}
.slot-footer{flex:1;min-width:0;}
.handoff{flex:none;display:flex;align-items:center;flex-wrap:wrap;gap:6px 10px;padding:0 14px 8px;background:var(--wsu-bg);}
.handoff[hidden]{display:none;}
.handoff .mode{flex:1 1 auto;min-width:0;display:flex;align-items:center;gap:6px;font-size:12px;color:var(--wsu-muted);}
.handoff .mode::before{content:"";flex:none;width:6px;height:6px;border-radius:50%;background:var(--wsu-muted);}
.modebtn{display:inline-flex;align-items:center;gap:6px;min-height:32px;padding:0 12px;border:1px solid var(--wsu-border);border-radius:999px;background:none;color:var(--wsu-text);font-size:12.5px;font-weight:700;line-height:1;white-space:nowrap;}
.modebtn .micon{display:inline-grid;font-size:15px;}
.modebtn:hover:not(:disabled){border-color:var(--wsu-primary);color:var(--wsu-primary);}
.modebtn:disabled{cursor:wait;opacity:.45;}
.modebtn[hidden]{display:none;}
.head .modebtn{min-height:28px;padding:0 10px;font-size:12px;}
.stage{position:relative;flex:1 1 0;min-height:0;display:flex;flex-direction:column;}
.list{flex:1 1 auto;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:14px;display:flex;flex-direction:column;gap:12px;background:var(--wsu-bg);}
.empty{margin:auto;color:var(--wsu-muted);text-align:center;}
.row{display:flex;flex-direction:column;align-items:flex-start;max-width:86%;min-width:0;}
.row.user{align-self:flex-end;align-items:flex-end;}
.byline{display:flex;align-items:baseline;gap:6px;font-size:11px;color:var(--wsu-muted);margin:0 4px 3px;}
.empty{font-size:13px;}
.byline:empty{display:none;}
.row .byline.after{margin:3px 4px 0;}
.who{font-weight:700;}
.bubble{max-width:100%;padding:8px 11px;font-size:13.5px;border:1px solid transparent;border-radius:var(--wsu-radius-bubble);border-end-start-radius:var(--wsu-radius-tail);background:var(--wsu-agent-bubble);color:var(--wsu-text);line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;}
.row.user .bubble{border-color:transparent;border-radius:var(--wsu-radius-bubble);border-end-end-radius:var(--wsu-radius-tail);background:var(--wsu-primary-soft);color:var(--wsu-text);}
.row.human .bubble{border-color:var(--wsu-border);background:var(--wsu-agent-bubble);border-inline-start:3px solid var(--wsu-primary);}
.bubble.media{padding:4px;}
.row.pending .bubble{opacity:.7;}
.row.failed .bubble{outline:1px solid var(--wsu-danger);}
.status{font-size:11px;color:var(--wsu-muted);margin:3px 4px 0;}
.status.err{color:var(--wsu-danger);}
.status button{border:0;background:none;color:var(--wsu-primary);text-decoration:underline;padding:0 0 0 6px;}
.files{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;white-space:normal;}
.bubble.media .files{margin-top:0;}
.files img{max-width:100%;width:auto;max-height:160px;object-fit:cover;border-radius:calc(var(--wsu-radius-bubble) - 4px);display:block;}
.files video{max-width:100%;max-height:180px;border-radius:calc(var(--wsu-radius-bubble) - 4px);display:block;background:#000;}
.files a{color:inherit;}
.divider{align-self:center;font-size:12px;color:var(--wsu-muted);background:var(--wsu-surface);border-radius:999px;padding:4px 12px;text-align:center;}
.rate{display:flex;gap:4px;margin:4px 2px 0;}
/* 鼠标设备：评价操作仅在这条 AI 回复被指向/聚焦时出现。
   opacity 而非 display/visibility 让 Tab 可进入，且消息布局不会因 hover 跳动。
   无 hover 的触屏设备沿用始终可见，避免无法发现评价入口。 */
@media (hover:hover) and (pointer:fine){
  .row.ai > .rate{opacity:0;pointer-events:none;transition:opacity .14s ease;}
  .row.ai:hover > .rate,.row.ai:focus-within > .rate{opacity:1;pointer-events:auto;}
}
@media (prefers-reduced-motion:reduce){.row.ai > .rate{transition:none;}}
.rate button{border:1px solid var(--wsu-border);background:var(--wsu-bg);color:var(--wsu-muted);border-radius:var(--wsu-radius-sm);padding:4px 7px;font-size:13px;}
.rate button[aria-pressed="true"]{color:var(--wsu-primary);border-color:var(--wsu-primary);background:var(--wsu-primary-soft);}
.reasons{margin-top:6px;padding:10px;border:1px solid var(--wsu-border);border-radius:var(--wsu-radius-sm);background:var(--wsu-surface);width:100%;}
.reasons .q{font-size:12px;color:var(--wsu-muted);margin-bottom:6px;}
.chips{display:flex;flex-wrap:wrap;gap:6px;}
.chips button{border:1px solid var(--wsu-border);background:var(--wsu-bg);border-radius:999px;padding:3px 10px;font-size:12px;}
.chips button[aria-pressed="true"]{border-color:var(--wsu-primary);color:var(--wsu-primary);}
.reasons textarea{width:100%;margin-top:8px;min-height:48px;resize:vertical;border:1px solid var(--wsu-border);border-radius:var(--wsu-radius-sm);background:var(--wsu-bg);padding:6px 8px;}
.reasons .actions{display:flex;justify-content:flex-end;margin-top:6px;}
.primary{border:0;background:var(--wsu-user-bubble);color:var(--wsu-on-user-bubble);border-radius:var(--wsu-radius-sm);padding:6px 14px;font-weight:600;}
.newmsg{position:absolute;left:50%;bottom:10px;transform:translateX(-50%);border:0;border-radius:999px;background:var(--wsu-user-bubble);color:var(--wsu-on-user-bubble);padding:4px 12px;font-size:12px;box-shadow:var(--wsu-shadow);white-space:nowrap;}
.newmsg[hidden]{display:none;}
.typing{flex:none;font-size:12px;color:var(--wsu-muted);padding:0 16px 6px;display:flex;align-items:center;gap:6px;}
.typing[hidden]{display:none;}
.dots{display:inline-flex;gap:3px;}
.dots i{width:5px;height:5px;border-radius:50%;background:currentColor;animation:wsu-b 1.2s infinite;}
.dots i:nth-child(2){animation-delay:.2s}.dots i:nth-child(3){animation-delay:.4s}
@keyframes wsu-b{0%,60%,100%{opacity:.25}30%{opacity:1}}
@media (prefers-reduced-motion: reduce){.dots i{animation:none;opacity:.6}.launcher{transition:none}}
.error{flex:none;margin:0 12px 8px;padding:6px 10px;border-radius:var(--wsu-radius-sm);background:var(--wsu-surface);color:var(--wsu-danger);font-size:12px;}
.error[hidden]{display:none;}
.chosen{flex:none;font-size:12px;color:var(--wsu-muted);padding:0 14px 6px;}
.chosen[hidden]{display:none;}
.compose{flex:none;padding:10px;border-top:1px solid var(--wsu-border);background:var(--wsu-bg);}
.field{display:flex;flex-direction:column;gap:6px;padding:8px;border:1px solid var(--wsu-border);border-radius:var(--wsu-radius-composer);background:var(--wsu-surface);transition:border-color .15s,box-shadow .15s;}
.field:focus-within{border-color:var(--wsu-primary);box-shadow:0 0 0 2px var(--wsu-primary-soft);}
.field textarea{display:block;width:100%;min-width:0;min-height:44px;max-height:120px;resize:none;border:0;background:transparent;padding:2px 2px 0;line-height:1.5;font-size:13.5px;}
.field textarea::placeholder{color:var(--wsu-muted);}
.field textarea:focus{outline:none;}
.tray{display:flex;flex-wrap:wrap;gap:8px;}
.tray[hidden]{display:none;}
.thumb{position:relative;display:block;width:56px;height:56px;border:1px solid var(--wsu-border);border-radius:10px;overflow:hidden;background:var(--wsu-bg);}
.thumb img,.thumb video{width:100%;height:100%;object-fit:cover;display:block;}
.thumb em{position:absolute;inset:auto 0 0 0;padding:2px 4px;background:rgba(0,0,0,.55);color:#fff;font-size:10px;font-style:normal;text-align:center;}
.thumb button{position:absolute;top:2px;inset-inline-end:2px;display:grid;place-items:center;width:18px;height:18px;padding:0;border:0;border-radius:999px;background:rgba(0,0,0,.55);color:#fff;font-size:11px;}
.tools{display:flex;align-items:center;justify-content:space-between;gap:8px;min-width:0;}
.tools-start{display:flex;align-items:center;gap:2px;min-width:0;flex-wrap:nowrap;}
.iconbtn{flex:none;border:0;background:transparent;color:var(--wsu-muted);width:30px;height:30px;display:grid;place-items:center;font-size:17px;border-radius:8px;}
.iconbtn:hover:not(:disabled){background:var(--wsu-bg);color:var(--wsu-text);}
.sendbtn{flex:none;margin-inline-start:auto;border:0;background:var(--wsu-user-bubble);color:var(--wsu-on-user-bubble);width:30px;height:30px;display:grid;place-items:center;font-size:16px;border-radius:999px;}
.sendbtn:hover:not(:disabled){filter:brightness(1.08);}
.sendbtn:disabled{background:var(--wsu-border);color:var(--wsu-muted);opacity:1;}
@media (max-width:480px){
  .root{bottom:12px;right:12px;}
  :host([data-position="bottom-left"]) .root{left:12px;}
  .panel{width:calc(100vw - 24px);height:calc(100vh - 90px);height:calc(100dvh - 90px);}
  :host([data-mode="inline"]) .panel{width:100%;height:auto;}
  .field textarea,.reasons textarea{font-size:16px;}
  .list{padding:12px 10px;}
  .row{max-width:92%;}
}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);}
`;
