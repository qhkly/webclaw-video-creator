/** script 嵌入入口（有副作用）：挂 globalThis.WebcodeSupport，按 <script data-*> 自动挂载。用法见 mount.js */

import * as widgetApi from './index.js';
import { hostCredentials } from '../adapters/host.js';
import { titleWithUnread } from '../adapters/titleBadge.js';

const { mount, optionsFromDataset } = widgetApi;

function autoMount() {
  const doc = globalThis.document;
  if (!doc) return;
  const script = doc.currentScript || doc.querySelector('script[data-webcode-support]');
  const ds = script?.dataset;
  if (!ds?.app || ds.auto === 'false') return;
  const go = () => {
    const opts = optionsFromDataset(ds);
    if (ds.container) opts.container = doc.querySelector(ds.container) || undefined;
    api.widget = mount(opts);
  };
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', go, { once: true });
  else go();
}

// 不 export：打包成无导出的 IIFE，全局只有这一个名字
const api = { ...widgetApi, hostCredentials, titleWithUnread, widget: null };

if (globalThis.document && !globalThis.WebcodeSupport) {
  globalThis.WebcodeSupport = api;
  autoMount();
}
