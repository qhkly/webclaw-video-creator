/**
 * 凭证提供方。**本包不含任何签名实现、不接受任何密钥**——浏览器里只拿服务端签好的东西。
 *
 * 统一凭证形状（客户端内部用，不落盘、不进 URL 之外的地方）：
 *   {
 *     scheme: 'legacy' | 'ticket',
 *     app, uid,                     // 会话身份；identityKey = app|uid
 *     expiresAt,                    // 毫秒；到点前 refreshMarginMs 重取
 *     loggedIn?: boolean,
 *     legacy?: {app, uid, ts, sig}, // scheme=legacy：服务端（官网 /api/support/session）签好的旧签名
 *     bearer?: string,              // scheme=ticket：ES256 短期票据，只放 Authorization 头
 *   }
 *
 * 三种来源：
 *   siteSessionCredentials  同源 GET /api/support/session（CCDub 官网 / WebClaw / Store 现状）
 *   ticketCredentials       GET /api/support/token → {ticket, uid, expiresAt(秒)}（AI Studio 契约）
 *   customCredentials       宿主自己取（例：扩展 content 向 background 要凭证、桌面端走 IPC）
 */

import { LEGACY_SIG_WINDOW_MS } from './protocol.js';

export class CredentialError extends Error {
  constructor(code, status = 0) {
    super(code);
    this.name = 'CredentialError';
    this.code = code;
    this.status = status;
  }
}

/** 这些键出现在凭证里 = 宿主把密钥带进了浏览器，直接拒绝 */
const FORBIDDEN_KEYS = /secret|private|signkey|sign_key|uid_key/i;

function assertNoSecretMaterial(obj, path = 'credential') {
  if (!obj || typeof obj !== 'object') return;
  for (const [k, v] of Object.entries(obj)) {
    if (FORBIDDEN_KEYS.test(k)) throw new CredentialError(`secret_in_credential:${path}.${k}`);
    if (v && typeof v === 'object') assertNoSecretMaterial(v, `${path}.${k}`);
  }
}

/** 校验并冻结一份凭证。所有提供方的出口都过这里 */
export function makeCredential(raw, { expectApp } = {}) {
  if (!raw || typeof raw !== 'object') throw new CredentialError('bad_credential');
  assertNoSecretMaterial(raw);
  const { scheme, app, uid } = raw;
  if (scheme !== 'legacy' && scheme !== 'ticket') throw new CredentialError('bad_scheme');
  if (typeof app !== 'string' || !app) throw new CredentialError('bad_app');
  if (typeof uid !== 'string' || !uid) throw new CredentialError('bad_uid');
  // 防串产品：官网同时挂多个产品面板（ccdub / ccdub-desktop）时，拿错产品的凭证会写进别的会话
  if (expectApp && app !== expectApp) throw new CredentialError('app_mismatch');
  const expiresAt = Number(raw.expiresAt);
  if (!Number.isFinite(expiresAt) || expiresAt <= 0) throw new CredentialError('bad_expiry');
  if (scheme === 'legacy') {
    const l = raw.legacy || {};
    if (l.app !== app || l.uid !== uid || !l.ts || typeof l.sig !== 'string' || !l.sig) {
      throw new CredentialError('bad_legacy_fields');
    }
  } else if (typeof raw.bearer !== 'string' || !raw.bearer) {
    throw new CredentialError('bad_bearer');
  }
  return Object.freeze({
    scheme,
    app,
    uid,
    identityKey: `${app}|${uid}`,
    expiresAt,
    loggedIn: raw.loggedIn === true,
    ...(scheme === 'legacy'
      ? { legacy: Object.freeze({ app, uid, ts: raw.legacy.ts, sig: raw.legacy.sig }) }
      : { bearer: raw.bearer }),
  });
}

/**
 * 带缓存与并发合并的提供方外壳。
 *   get()            有效就复用，快过期才重取；并发调用共享一次请求
 *   get({force})     Worker 回 401 后强制重取
 *   clear()          登出 / 切账号
 */
function cached(load, { refreshMarginMs = 30_000, now = () => Date.now() } = {}) {
  let current = null;
  let inflight = null;
  let generation = 0;
  return {
    async get({ force = false } = {}) {
      if (!force && current && current.expiresAt - refreshMarginMs > now()) return current;
      if (inflight) return inflight;
      const gen = generation;
      inflight = (async () => {
        try {
          const c = await load();
          // clear() 发生在取凭证途中：丢掉旧账号的结果，别把 A 的凭证塞回 B 的会话
          if (gen !== generation) throw new CredentialError('cleared');
          current = c;
          return c;
        } finally {
          inflight = null;
        }
      })();
      return inflight;
    },
    peek: () => current,
    clear() {
      generation += 1;
      current = null;
      inflight = null;
    },
  };
}

async function readJson(res) {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

/**
 * 同源会话签名端点（dub_precedent / webclaw-platform / webclaw-store 的 /api/support/session）。
 * 响应：{app, origin, uid, ts, sig, ttlMs, loggedIn}。uid 由服务端决定（登录邮箱或 httpOnly 匿名 cookie）。
 */
export function siteSessionCredentials({
  url = '/api/support/session',
  fetch: f = globalThis.fetch,
  expectApp,
  refreshMarginMs,
  now = () => Date.now(),
} = {}) {
  return cached(async () => {
    const res = await f(url, { credentials: 'same-origin', cache: 'no-store' });
    const body = await readJson(res);
    if (!res.ok || !body) throw new CredentialError(body?.error || `http_${res.status}`, res.status);
    const ts = Number(body.ts);
    // ttlMs 是服务端给的（官网 4 分钟）；没给就按签名窗口算，且绝不超过窗口
    const ttl = Math.min(Number(body.ttlMs) || LEGACY_SIG_WINDOW_MS, LEGACY_SIG_WINDOW_MS);
    return makeCredential({
      scheme: 'legacy',
      app: body.app,
      uid: body.uid,
      loggedIn: body.loggedIn,
      expiresAt: (Number.isFinite(ts) && ts > 0 ? Math.min(ts, now()) : now()) + ttl,
      legacy: { app: body.app, uid: body.uid, ts: body.ts, sig: body.sig },
    }, { expectApp });
  }, { refreshMarginMs, now });
}

/**
 * 短期账号票据（webcode-ai-studio docs/support-ticket-contract.md §3）。
 * 响应：{ticket, uid, expiresAt}，expiresAt 是秒。只在内存，不进 localStorage、不进 URL。
 * headers 可以是函数（桌面端每次带最新登录 token）；网页端靠同源 cookie。
 */
export function ticketCredentials({
  url = '/api/support/token',
  app,
  fetch: f = globalThis.fetch,
  headers,
  refreshMarginMs = 60_000,
  now = () => Date.now(),
} = {}) {
  if (!app) throw new CredentialError('bad_app');
  return cached(async () => {
    const sep = url.includes('?') ? '&' : '?';
    const h = typeof headers === 'function' ? await headers() : headers;
    const res = await f(`${url}${sep}app=${encodeURIComponent(app)}`, {
      credentials: 'same-origin', cache: 'no-store', headers: h || {},
    });
    const body = await readJson(res);
    if (!res.ok || !body) throw new CredentialError(body?.error || `http_${res.status}`, res.status);
    return makeCredential({
      scheme: 'ticket', app, uid: body.uid, bearer: body.ticket, expiresAt: Number(body.expiresAt) * 1000,
    }, { expectApp: app });
  }, { refreshMarginMs, now });
}

/**
 * 宿主自取。load() 返回 makeCredential 能接受的对象（scheme/app/uid/expiresAt/legacy|bearer）。
 * CCDub 扩展过渡期：load 向 background 要现签的旧签名——签名逻辑留在扩展原处（既有安全债），
 * 不进本包。
 */
export function customCredentials(load, { expectApp, refreshMarginMs, now } = {}) {
  return cached(async () => makeCredential(await load(), { expectApp }), { refreshMarginMs, now });
}
