export * from './protocol.js';
export { createSupportClient, SupportApiError, DEFAULT_ORIGIN } from './client.js';
export {
  siteSessionCredentials, ticketCredentials, customCredentials, makeCredential, CredentialError,
} from './credentials.js';
export { createSupportStore, initialState, canRate, TYPING_MAX_MS } from './store.js';
export { createSupportSession } from './session.js';
export { createTranslator, errorMessageKey, MESSAGE_KEYS, FALLBACK } from './i18n.js';
export { titleWithUnread, stripUnreadTitle } from './adapters/titleBadge.js';
export { hostCredentials, bindExtensionPush } from './adapters/host.js';
