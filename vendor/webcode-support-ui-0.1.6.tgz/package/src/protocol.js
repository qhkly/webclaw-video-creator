/**
 * support.qhkly.com 用户侧协议（权威来源：worker/src/index.js 等）。
 *
 * 本文件只描述「线上 Worker 实际怎么说话」，不发明新字段。契约测试
 * （test/contract-worker.test.mjs）直接在进程内跑真实 Worker 代码，任何一边漂移都会挂。
 *
 * 规范化函数一律容忍旧服务端：缺字段按「没有这个能力」处理，不抛错。
 */

/** 用户侧端点。全部带 CORS *，鉴权见 credentials.js */
export const ENDPOINTS = Object.freeze({
  send: '/api/send', // POST
  handoff: '/api/handoff', // POST  转人工（幂等）
  aiResume: '/api/ai-resume', // POST  返回 AI（只限本轮自己请求的人工）
  poll: '/api/poll', // GET   增量消息 + 会话状态
  typing: '/api/typing', // GET   只读实时状态（单次同步用）
  unread: '/api/unread', // GET   未读数
  feedback: '/api/feedback', // POST 评价 / GET 自己最近的评价
  watchTicket: '/api/watch-ticket', // GET events 订阅票
  upload: '/api/upload', // POST  原始字节，鉴权在 query
  file: '/file/', // GET   附件（鉴权在 query）
});

/** 消息角色。admin = 人工客服；ai = AI 客服或系统确认（见 event） */
export const ROLES = Object.freeze({ USER: 'user', AI: 'ai', HUMAN: 'admin' });

/** poll 下发的 event 枚举（index.js modeEventOf） */
export const MESSAGE_EVENTS = Object.freeze({
  REQUEST_HUMAN: 'request_human', // 用户点了转人工（role=user）
  RESUME_AI: 'resume_ai', // 用户点了返回 AI（role=user）
  HUMAN_ACK: 'human_ack', // 转人工的系统确认（role=ai，不是 AI 回答，不可评价）
});

/** support_mode（ai.js supportModeOf） */
export const SUPPORT_MODES = Object.freeze({
  AI: 'ai',
  HUMAN_REQUESTED: 'human_requested', // 用户自己请求的人工：可自助返回 AI
  HUMAN: 'human', // 管理员接管：不能返回 AI
});

/** 点踩原因（feedback.js REASONS，顺序即显示顺序） */
export const FEEDBACK_REASONS = Object.freeze(['wrong', 'irrelevant', 'unclear', 'not_solved', 'want_human', 'other']);
export const FEEDBACK_COMMENT_MAX = 300;
export const RATINGS = Object.freeze({ UP: 'up', DOWN: 'down' });

/** typing.actor */
export const TYPING_ACTORS = Object.freeze({ AI: 'ai', HUMAN: 'human' });

/** 服务端消息长度上限（ratelimit.js MAX_TEXT_LEN）。客户端只用来提前提示，服务端仍会再判 */
export const MAX_TEXT_LEN = 2000;
/** 单条消息最多附件数（index.js handleSend slice(0, 6)） */
export const MAX_FILES = 6;

/** 旧共享签名的时间窗（index.js SIG_WINDOW_MS）。凭证提供方据此决定何时重取 */
export const LEGACY_SIG_WINDOW_MS = 5 * 60 * 1000;

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const VALID_MODES = new Set(Object.values(SUPPORT_MODES));
const VALID_EVENTS = new Set(Object.values(MESSAGE_EVENTS));

/**
 * 一条 poll 消息 → 面板用的统一形状。
 * kind 是 UI 唯一需要的判别：user / ai / human / system（转人工确认）。
 */
export function normalizeMessage(raw) {
  if (!isObj(raw)) return null;
  const id = Number(raw.id);
  if (!Number.isSafeInteger(id) || id <= 0) return null;
  const role = raw.role === 'user' || raw.role === 'ai' || raw.role === 'admin' ? raw.role : null;
  if (!role) return null;
  const event = VALID_EVENTS.has(raw.event) ? raw.event : null;
  let kind;
  if (role === 'user') kind = 'user';
  else if (role === 'admin') kind = 'human';
  else kind = event === MESSAGE_EVENTS.HUMAN_ACK ? 'system' : 'ai';
  return {
    id,
    role,
    kind,
    event,
    text: typeof raw.text === 'string' ? raw.text : '',
    files: Array.isArray(raw.files) ? raw.files.filter((k) => typeof k === 'string') : [],
    at: Number(raw.at) || 0,
    // 只有服务端明确下发 rateable 才可评价；旧服务端/人工/系统确认一律 false
    rateable: raw.rateable === true && kind === 'ai',
    feedback: normalizeFeedback(raw.feedback),
  };
}

export function normalizeFeedback(raw) {
  if (!isObj(raw)) return null;
  if (raw.rating !== 'up' && raw.rating !== 'down') return null;
  return {
    rating: raw.rating,
    reason: raw.rating === 'down' && FEEDBACK_REASONS.includes(raw.reason) ? raw.reason : null,
    ...(typeof raw.comment === 'string' && raw.comment ? { comment: raw.comment } : {}),
  };
}

/** typing 值：null 或 {actor, ttl_ms} */
export function normalizeTyping(raw) {
  if (!isObj(raw)) return null;
  if (raw.actor !== 'ai' && raw.actor !== 'human') return null;
  const ttl = Number(raw.ttl_ms);
  return { actor: raw.actor, ttlMs: Number.isFinite(ttl) && ttl > 0 ? ttl : 0 };
}

/**
 * /api/poll 响应。旧服务端只有 messages/status/human_requested，其余字段按缺省降级：
 *   - 没有 support_mode：human_requested=true → human_requested，否则 ai
 *   - 没有 typing_push：视为 false（需要兜底轮询）
 *   - 没有 feedback_enabled：视为 false（不显示评价按钮）
 */
export function normalizePoll(raw) {
  const body = isObj(raw) ? raw : {};
  const messages = (Array.isArray(body.messages) ? body.messages : []).map(normalizeMessage).filter(Boolean);
  let mode = VALID_MODES.has(body.support_mode) ? body.support_mode : null;
  if (!mode) mode = body.human_requested === true ? SUPPORT_MODES.HUMAN_REQUESTED : SUPPORT_MODES.AI;
  const hasTyping = 'typing' in body;
  return {
    messages,
    status: typeof body.status === 'string' ? body.status : 'none',
    supportMode: mode,
    typing: hasTyping ? normalizeTyping(body.typing) : undefined,
    typingRev: Number.isFinite(Number(body.typing_rev)) && body.typing_rev != null ? Number(body.typing_rev) : null,
    typingPush: body.typing_push === true,
    feedbackEnabled: body.feedback_enabled === true,
    schedule: isObj(body.schedule) ? body.schedule : null,
  };
}

/**
 * events WebSocket 帧（events/src/support-channel.ts）：
 *   {type:'support_cursor', lastId, ...}         连上时的游标（payload 可能是上一条 typing 帧，忽略其 typing）
 *   {type:'support_notify', lastId}              有新消息
 *   {type:'support_notify', kind:'typing', lastId:0, typing, rev}  实时状态变化
 * 'pong' 是 ping 的自动应答。
 */
export function parseWatchFrame(data) {
  if (data === 'pong') return { type: 'pong' };
  let f;
  try {
    f = typeof data === 'string' ? JSON.parse(data) : null;
  } catch {
    return null;
  }
  if (!isObj(f)) return null;
  const lastId = Number(f.lastId) || 0;
  if (f.type === 'support_cursor') return { type: 'cursor', lastId };
  if (f.type !== 'support_notify') return null;
  if (f.kind === 'typing') {
    const rev = Number(f.rev);
    return { type: 'typing', typing: normalizeTyping(f.typing), rev: Number.isFinite(rev) ? rev : null };
  }
  return { type: 'notify', lastId };
}

/** 服务端错误码 → 面板要做的事（不含文案） */
export const ERROR_ACTIONS = Object.freeze({
  bad_signature: 'reauth',
  bad_ticket: 'reauth',
  ticket_required: 'reauth',
  too_fast: 'wait', // 每分钟消息/评价频控
  daily_quota: 'wait', // 每日新工单配额
  too_large: 'fix_input',
  unsupported_type: 'fix_input',
  too_long: 'fix_input',
  empty: 'fix_input',
  human_takeover: 'sync_mode',
  not_resumable: 'sync_mode',
  not_rateable: 'sync',
  not_found: 'sync',
  unavailable: 'feature_off',
  watch_disabled: 'feature_off',
});
