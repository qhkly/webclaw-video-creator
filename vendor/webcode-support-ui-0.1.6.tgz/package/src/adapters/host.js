/**
 * 宿主薄适配：桌面端 WebView 与浏览器扩展。只做「把宿主已有的东西接进 session」，不含任何签名。
 */

import { customCredentials } from '../credentials.js';
import { normalizeTyping } from '../protocol.js';

/**
 * 桌面端 WebView：凭证由原生侧签发（Tauri invoke / WebView2 postMessage / IPC），页面只拿结果。
 *
 *   request() → 票据 {ticket, uid, expiresAt(秒)}           （推荐：AI Studio 桌面 chatgpt/7dce4342 的形状）
 *            或 旧签名 {app, uid, ts, sig, ttlMs?}          （过渡：原生侧签好的旧签名，密钥仍不进页面）
 *
 * 例（Tauri）：hostCredentials({ app: 'ai-studio', request: () => invoke('support_ticket') })
 */
export function hostCredentials({ app, request, now = () => Date.now(), refreshMarginMs } = {}) {
  if (!app || typeof request !== 'function') throw new TypeError('app and request() required');
  return customCredentials(async () => {
    const r = await request();
    if (!r || typeof r !== 'object') throw new Error('bad_host_credential');
    // 原样带上宿主返回的全部字段：makeCredential 会拒绝其中任何密钥形字段（原生侧误把密钥传进页面）
    if (typeof r.ticket === 'string') {
      return { ...r, scheme: 'ticket', app, uid: r.uid, bearer: r.ticket, expiresAt: Number(r.expiresAt) * 1000 };
    }
    const ttl = Math.min(Number(r.ttlMs) || 240_000, 300_000);
    return {
      ...r,
      scheme: 'legacy', app: r.app, uid: r.uid, loggedIn: r.loggedIn === true,
      expiresAt: Math.min(Number(r.ts) || now(), now()) + ttl,
      legacy: { app: r.app, uid: r.uid, ts: r.ts, sig: r.sig },
    };
  }, { expectApp: app, now, refreshMarginMs });
}

const uidOf = (identityKey) => (identityKey ? identityKey.slice(identityKey.indexOf('|') + 1) : null);

/**
 * 浏览器扩展：background 常驻 events 长连接（packages/shared/core/src/js/background.js），
 * 经 runtime 消息广播三种帧。session 用 push:'external'，这里把它们喂进去：
 *
 *   {type:'supportNotify'}                       有新消息 → poll（收起态 → 查未读）
 *   {type:'supportTypingEvent', uid, typing, rev} 只认与当前身份一致的 uid（切号瞬间旧连接的帧不串号）
 *   {type:'supportWatchState', connected}        决定要不要开兜底轮询
 *
 * @param {object} runtime  chrome.runtime / browser.runtime（需要 onMessage.addListener/removeListener）
 * @returns {() => void} 解绑
 */
export function bindExtensionPush(session, runtime) {
  const listener = (msg) => {
    if (!msg || typeof msg !== 'object') return undefined;
    if (msg.type === 'supportNotify') {
      session.handlePushFrame({ type: 'notify', lastId: Number.MAX_SAFE_INTEGER });
    } else if (msg.type === 'supportTypingEvent') {
      const mine = uidOf(session.store.getState().identityKey);
      if (mine && msg.uid === mine) {
        const rev = Number(msg.rev);
        session.handlePushFrame({ type: 'typing', typing: normalizeTyping(msg.typing), rev: Number.isFinite(rev) ? rev : null });
      }
    } else if (msg.type === 'supportWatchState') {
      session.setPushConnected(msg.connected === true);
    }
    return undefined; // 不应答：不 return true，别让发送方等一个永远不来的回复
  };
  runtime.onMessage.addListener(listener);
  return () => runtime.onMessage.removeListener(listener);
}
