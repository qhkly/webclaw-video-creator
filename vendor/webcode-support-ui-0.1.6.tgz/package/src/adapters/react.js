/**
 * React 轻适配。React 由宿主传入（本包不依赖、不打包 React），无 JSX，任何构建链都能直接 import。
 *
 *   const state = useSupportState(React, session.store);
 *   useSupportSessionLifecycle(React, session, { enabled: open });
 */

export function useSupportState(React, store) {
  return React.useSyncExternalStore(store.subscribe, store.getState, store.getState);
}

/** 面板打开时 start、关闭/卸载时 stop。session 实例由宿主按 product 建一次（不要每次渲染新建） */
export function useSupportSessionLifecycle(React, session, { enabled = true } = {}) {
  React.useEffect(() => {
    if (!enabled || !session) return undefined;
    session.start();
    return () => session.stop();
  }, [React, session, enabled]);
}

/** typing 过期需要重渲染：只在显示中时挂一个到期定时器 */
export function useActiveTyping(React, store) {
  const state = useSupportState(React, store);
  const [, force] = React.useReducer((x) => x + 1, 0);
  const actor = state.typing && state.typing.expiresAt > Date.now() ? state.typing.actor : null;
  React.useEffect(() => {
    if (!actor) return undefined;
    const t = setTimeout(force, Math.max(0, state.typing.expiresAt - Date.now()) + 20);
    return () => clearTimeout(t);
  }, [actor, state.typing]);
  return actor;
}
