/**
 * 「(N) 标题」未读前缀。CCDub Desktop 外壳读页面标题的 (N) 前缀显示 dock 角标
 * （ccdub-desktop apps/desktop/src-tauri/src/support.rs unread_from_title：只认 1~2 位纯数字）。
 * 这是跨工程契约，与 dub_precedent lib/supportChat.ts titleWithUnread 逐字一致：
 * N 是确切数字、不封顶、不写「9+」（写了外壳会读成 0）。已有前缀先去掉，不叠加。
 */
const TITLE_PREFIX_RE = /^\(\d+\)\s+/;

export function stripUnreadTitle(title) {
  return String(title || '').replace(TITLE_PREFIX_RE, '');
}

export function titleWithUnread(title, n) {
  const base = stripUnreadTitle(title);
  const count = Number.isFinite(Number(n)) ? Math.floor(Number(n)) : 0;
  return count > 0 ? `(${count}) ${base}` : base;
}
