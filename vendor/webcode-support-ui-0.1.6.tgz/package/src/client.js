/**
 * support Worker 的用户侧 HTTP 客户端。无状态（状态在 store.js），无框架依赖。
 *
 * 鉴权由凭证决定，调用方不碰：
 *   legacy  GET 放 query（app, uid, ts, sig），POST 放 JSON body —— 与线上各站逐字一致
 *   ticket  Authorization: Bearer <ticket>，另带 app（Worker 用它判定租户）；
 *           不发 uid/ts/sig/token（票据租户的 Worker 一律不看，旧桌面端曾把登录 JWT 放进 token）
 * 401 一律强制重取凭证并只重试一次。
 */

import { ENDPOINTS, FEEDBACK_REASONS, FEEDBACK_COMMENT_MAX, normalizePoll, normalizeTyping, normalizeFeedback } from './protocol.js';

export const DEFAULT_ORIGIN = 'https://support.qhkly.com';

export class SupportApiError extends Error {
  constructor(code, { status = 0, retryAfter = 0, body = null } = {}) {
    super(code);
    this.name = 'SupportApiError';
    this.code = code;
    this.status = status;
    this.retryAfter = retryAfter;
    this.body = body;
  }
}

/**
 * @param {object} opts
 * @param {{get: Function, clear?: Function}} opts.credentials  credentials.js 的提供方
 * @param {string} [opts.origin]
 * @param {Function} [opts.fetch]
 * @param {() => (string|null|Promise<string|null>)} [opts.getToken]  旧租户的浏览器/设备 token（限流 + 推送地址），可选
 */
export function createSupportClient({ credentials, origin = DEFAULT_ORIGIN, fetch: f = globalThis.fetch, getToken } = {}) {
  if (!credentials || typeof credentials.get !== 'function') throw new TypeError('credentials provider required');
  const base = String(origin).replace(/\/+$/, '');

  const tokenFor = async (cred) => {
    if (cred.scheme !== 'legacy' || !getToken) return undefined;
    const t = await getToken();
    return typeof t === 'string' && t ? t : undefined;
  };

  function authQuery(cred, extra = {}) {
    const q = new URLSearchParams();
    if (cred.scheme === 'legacy') {
      const { app, uid, ts, sig } = cred.legacy;
      q.set('app', app);
      q.set('uid', uid);
      q.set('ts', String(ts));
      q.set('sig', sig);
    } else {
      q.set('app', cred.app);
    }
    for (const [k, v] of Object.entries(extra)) if (v !== undefined && v !== null) q.set(k, String(v));
    return q.toString();
  }

  const authHeaders = (cred) => (cred.scheme === 'ticket' ? { Authorization: `Bearer ${cred.bearer}` } : {});
  const authBody = (cred) => (cred.scheme === 'legacy' ? { ...cred.legacy } : { app: cred.app });

  async function parse(res) {
    let body = null;
    try {
      body = await res.json();
    } catch {
      body = null;
    }
    if (res.ok) return body || {};
    throw new SupportApiError(body?.error || `http_${res.status}`, {
      status: res.status, retryAfter: Number(body?.retryAfter) || 0, body,
    });
  }

  /** build(cred, token) → [url, init]。401 时换新凭证重建一次 */
  async function request(build, { raw = false } = {}) {
    let cred = await credentials.get();
    for (let attempt = 0; ; attempt++) {
      const [url, init] = build(cred, await tokenFor(cred));
      const res = await f(url, init);
      if (res.status === 401 && attempt === 0) {
        cred = await credentials.get({ force: true });
        continue;
      }
      if (raw) {
        if (!res.ok) await parse(res);
        return { res, cred };
      }
      return { body: await parse(res), cred };
    }
  }

  // 只读接口不带 token：Worker 只在写路径（send/handoff/feedback/upload）用它
  const get = (path, extra = {}) => request((cred) => [
    `${base}${path}?${authQuery(cred, extra)}`,
    { method: 'GET', cache: 'no-store', headers: authHeaders(cred) },
  ]);

  const post = (path, payload = {}) => request((cred, token) => [
    `${base}${path}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cred) },
      body: JSON.stringify({ ...payload, ...authBody(cred), ...(token ? { token } : {}) }),
    },
  ]);

  return {
    origin: base,
    credentials,

    /** 增量拉取。since = 已有的最大消息 id */
    async poll(since = 0) {
      const { body, cred } = await get(ENDPOINTS.poll, { since: Math.max(0, Number(since) || 0) });
      return { ...normalizePoll(body), identityKey: cred.identityKey };
    },

    /** 发消息。files = upload 返回的 key（必须在自己的 app/uid 前缀下，Worker 会再挡） */
    async send({ text = '', lang, files, meta } = {}) {
      const { body, cred } = await post(ENDPOINTS.send, {
        text, lang, ...(files?.length ? { files } : {}), ...(meta ? { meta } : {}),
      });
      return { id: Number(body.id) || 0, dedup: body.dedup === true, translated: body.translated, identityKey: cred.identityKey };
    },

    /** 转人工。返回 {mode, already} */
    async handoff({ lang } = {}) {
      const { body } = await post(ENDPOINTS.handoff, { lang });
      return { mode: body.mode || 'human_requested', already: body.already === true };
    },

    /** 返回 AI。409 抛错，err.body.mode 是服务端当下的模式 */
    async aiResume({ lang } = {}) {
      const { body } = await post(ENDPOINTS.aiResume, { lang });
      return { mode: body.mode || 'ai', already: body.already === true };
    },

    /**
     * 评价一条 AI 消息。rating: 'up' | 'down' | null（取消）。
     * reason/comment 只在 down 时发送（与 Worker parseFeedbackInput 一致：赞带原因会被清掉）。
     */
    async feedback({ msgId, rating, reason, comment } = {}) {
      const id = Number(msgId);
      if (!Number.isSafeInteger(id) || id <= 0) throw new SupportApiError('bad_msg_id');
      if (rating !== null && rating !== 'up' && rating !== 'down') throw new SupportApiError('bad_rating');
      if (rating === 'down' && reason != null && !FEEDBACK_REASONS.includes(reason)) throw new SupportApiError('bad_reason');
      const payload = { msg_id: id, rating };
      if (rating === 'down') {
        if (reason) payload.reason = reason;
        if (typeof comment === 'string' && comment.trim()) payload.comment = comment.trim().slice(0, FEEDBACK_COMMENT_MAX);
      }
      const { body } = await post(ENDPOINTS.feedback, payload);
      return { msgId: Number(body.msg_id) || id, feedback: normalizeFeedback(body.feedback) };
    },

    /** 自己最近的评价（对账用）→ Map<msgId, feedback> */
    async feedbackList() {
      const { body } = await get(ENDPOINTS.feedback);
      const map = new Map();
      for (const r of Array.isArray(body.feedback) ? body.feedback : []) {
        const fb = normalizeFeedback(r);
        if (fb && Number(r.msg_id) > 0) map.set(Number(r.msg_id), fb);
      }
      return map;
    },

    async typing() {
      const { body } = await get(ENDPOINTS.typing);
      const rev = Number(body.rev);
      return { typing: normalizeTyping(body.typing), rev: Number.isFinite(rev) ? rev : null, typingPush: body.typing_push === true };
    },

    async unread() {
      const { body } = await get(ENDPOINTS.unread);
      return Math.max(0, Number(body.unread) || 0);
    },

    /** events 订阅票。501 watch_disabled = 实时提醒没开，调用方退回轮询 */
    async watchTicket() {
      const { body } = await get(ENDPOINTS.watchTicket);
      if (typeof body.url !== 'string' || typeof body.token !== 'string') throw new SupportApiError('bad_ticket_response');
      return { url: body.url, token: body.token, ttlMs: Number(body.ttlMs) || 15 * 60_000 };
    },

    /** 上传原始字节（图片/短录屏）。返回 {key, mime} */
    async upload(blob) {
      const { body } = await request((cred, token) => [
        `${base}${ENDPOINTS.upload}?${authQuery(cred, token ? { token } : {})}`,
        { method: 'POST', headers: { ...authHeaders(cred) }, body: blob },
      ]);
      if (typeof body.key !== 'string') throw new SupportApiError('bad_upload_response');
      return { key: body.key, mime: body.mime || null };
    },

    /**
     * 附件地址。只有旧签名能直接拼 URL（签名在 query 里，5 分钟内有效）；
     * 票据凭证不能进 URL，返回 null —— 调用方改用 fetchFile 拿 Blob。
     */
    async fileUrl(key) {
      const cred = await credentials.get();
      if (cred.scheme !== 'legacy') return null;
      return `${base}${ENDPOINTS.file}${encodeURIComponent(key)}?${authQuery(cred)}`;
    },

    async fetchFile(key) {
      const { res } = await request((cred) => [
        `${base}${ENDPOINTS.file}${encodeURIComponent(key)}?${authQuery(cred)}`,
        { method: 'GET', headers: authHeaders(cred) },
      ], { raw: true });
      return res.blob();
    },
  };
}
