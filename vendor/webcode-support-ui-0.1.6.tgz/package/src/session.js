/**
 * 客服会话编排：推送 / 兜底轮询 / 重连 / typing / 账号切换 / 用户动作。
 *
 * 取舍沿用 CCDub 官网与扩展线上已验证的节奏：
 *   - 推送连着：零周期请求。只在 打开 / 推送（重）连上 / 页面重新可见 时各同步一次。
 *   - 推送断开：/api/poll 每 pollMs（默认 5s，页面隐藏时 hiddenPollMs，默认不轮询）。
 *   - typing：推送连着且服务端 typing_push=true → 只靠推送；否则页面可见 + 会话进行中才 2s 兜底。
 *   - 重连：1s 起翻倍，封顶 30s，带抖动；连上即清零。换票在 80% TTL 静默进行，不断流。
 *   - 推送连接只按 identityKey(app|uid) 建立：凭证每 4 分钟刷新一次不重连。
 *   - 身份变化（凭证刷新回来的 uid 变了 / 宿主调用 resetIdentity）：清空状态、断开旧连接、
 *     从 since=0 重新拉。迟到的旧身份结果一律丢弃。
 *
 * active（面板展开 / 收起）：
 *   true   完整会话：poll 拉消息（服务端「拉过就算已读」）、typing、评价对账
 *   false  只看未读：推送帧 / 兜底定时器只调 /api/unread，绝不 poll ——
 *          否则面板收起时新回复会被标成已读，未读角标永远亮不起来。
 *          FAB 与面板共用同一个 session（一条推送连接），展开时 setActive(true)。
 *
 * push 选项：
 *   'websocket' 本会话自己换票连 events（网页）
 *   'external'  宿主自有长连接（扩展 background），把帧经 handlePushFrame / setPushConnected 喂进来
 *   'none'      只轮询
 */

import { parseWatchFrame, SUPPORT_MODES } from './protocol.js';
import { createSupportStore } from './store.js';
import { SupportApiError } from './client.js';

const ACTIVE_THREAD = new Set(['pending', 'open']);

export function createSupportSession({
  client,
  store = createSupportStore(),
  push = 'websocket',
  WebSocket: WS = globalThis.WebSocket,
  setTimeout: st = globalThis.setTimeout.bind(globalThis),
  clearTimeout: ct = globalThis.clearTimeout.bind(globalThis),
  visibility = defaultVisibility(),
  random = Math.random,
  pollMs = 5_000,
  hiddenPollMs = 0,
  typingPollMs = 2_000,
  pingMs = 25_000,
  minBackoffMs = 1_000,
  maxBackoffMs = 30_000,
  reconcileFeedbackOnOpen = true,
  active: initialActive = true,
  unreadPollMs = 60_000,
  onEvent = () => {},
} = {}) {
  let runId = 0;
  let running = false;
  let ws = null;
  let pushDisabled = push === 'none';
  let backoff = minBackoffMs;
  const timers = { poll: null, typing: null, reconnect: null, ping: null, renew: null };
  let ticket = null;
  let polling = null;
  let pollAgain = false;
  let clientSeq = 0;
  let unsubVisibility = null;
  let active = initialActive !== false;
  let unreadInflight = null;

  const clear = (name) => {
    if (timers[name]) ct(timers[name]);
    timers[name] = null;
  };
  const clearAll = () => Object.keys(timers).forEach(clear);
  const alive = (id) => running && id === runId;

  /* ------------------------------------------------------------ 同步 */

  async function pollNow() {
    if (polling) {
      pollAgain = true;
      return polling;
    }
    const id = runId;
    let switched = false;
    polling = (async () => {
      try {
        do {
          pollAgain = false;
          const seq = store.getState().modeSeq;
          const r = await client.poll(store.getState().lastId);
          if (!alive(id)) return;
          if (r.identityKey !== store.getState().identityKey) {
            // 凭证刷新带回了另一个 uid = 账号变了：整份重来
            // 不能在这里 await restart：restart → begin → pollNow 会等本次 polling 自己
            onEvent({ type: 'identity_changed', from: store.getState().identityKey, to: r.identityKey });
            switched = true;
            return;
          }
          store.applyPoll(r, seq);
        } while (pollAgain && alive(id));
      } catch (err) {
        if (alive(id)) {
          store.setError(errCode(err));
          onEvent({ type: 'poll_error', error: errCode(err) });
        }
      } finally {
        polling = null;
        if (switched && alive(id)) restart();
        else if (alive(id)) schedule();
      }
    })();
    return polling;
  }

  async function syncTyping() {
    const id = runId;
    try {
      const key = store.getState().identityKey;
      const r = await client.typing();
      if (alive(id)) store.applyTyping({ ...r, identityKey: key });
    } catch {
      /* 下一拍再试；typing 只是提示 */
    } finally {
      if (alive(id)) schedule();
    }
  }

  /** 收起态：只查未读。凭证刷新回来身份变了同样整份重来 */
  function syncUnread() {
    if (unreadInflight) return unreadInflight;
    const id = runId;
    const key = store.getState().identityKey;
    const p = (async () => {
      try {
        const n = await client.unread();
        if (!alive(id)) return;
        const now = client.credentials.peek?.()?.identityKey;
        if (now && now !== store.getState().identityKey) {
          onEvent({ type: 'identity_changed', from: store.getState().identityKey, to: now });
          unreadInflight = null;
          restart();
          return;
        }
        store.setUnread(n, { identityKey: key });
      } catch (err) {
        if (alive(id)) onEvent({ type: 'unread_error', error: errCode(err) });
      } finally {
        if (unreadInflight === p) unreadInflight = null;
        if (alive(id)) schedule();
      }
    })();
    unreadInflight = p;
    return p;
  }

  /** 按当前连接/可见性重排兜底定时器 */
  function schedule() {
    if (!running) return;
    const s = store.getState();
    const visible = visibility.isVisible();
    const connected = s.connected;

    if (!active) {
      clear('typing');
      const every = connected || !visible ? 0 : unreadPollMs;
      if (every <= 0) clear('poll');
      else if (!timers.poll) timers.poll = st(() => { timers.poll = null; syncUnread(); }, every);
      return;
    }

    // 已排着的同类定时器保留不动：每次重排都重置的话，2s 一次的 typing 会把 5s 的 poll 永远推后
    const interval = connected ? 0 : visible ? pollMs : hiddenPollMs;
    if (interval <= 0) clear('poll');
    else if (!timers.poll) timers.poll = st(() => { timers.poll = null; pollNow(); }, interval);

    const needTypingPoll = visible && ACTIVE_THREAD.has(s.threadStatus) && (!connected || !s.typingPush) && typingPollMs > 0;
    if (!needTypingPoll) clear('typing');
    else if (!timers.typing) timers.typing = st(() => { timers.typing = null; syncTyping(); }, typingPollMs);
  }

  /* ------------------------------------------------------------ 推送 */

  function handlePushFrame(data) {
    const f = typeof data === 'object' && data && data.type ? data : parseWatchFrame(data);
    if (!f) return;
    if (f.type === 'typing') {
      store.applyTyping({ typing: f.typing, rev: f.rev });
    } else if (!active) {
      if (f.type === 'notify' || f.type === 'cursor') syncUnread();
    } else if ((f.type === 'notify' || f.type === 'cursor') && f.lastId > store.getState().lastId) {
      pollNow();
    }
  }

  function setPushConnected(connected) {
    const was = store.getState().connected;
    store.setConnected(Boolean(connected));
    if (Boolean(connected) !== was) { clear('poll'); clear('typing'); }
    // 刚（重）连上：补一次同步，断线期间的消息/状态都在这里追上
    if (connected && !was) {
      if (active) {
        pollNow();
        syncTyping();
      } else {
        syncUnread();
      }
    }
    schedule();
  }

  async function connect() {
    if (push !== 'websocket' || pushDisabled || !WS || !running) return;
    const id = runId;
    try {
      if (!ticket) ticket = await client.watchTicket();
    } catch (err) {
      if (!alive(id)) return;
      if (err instanceof SupportApiError && (err.status === 501 || err.code === 'watch_disabled')) {
        pushDisabled = true; // 实时提醒没开：老老实实轮询，不再换票
        onEvent({ type: 'push_disabled' });
        return;
      }
      return reconnectLater(id);
    }
    if (!alive(id)) return;
    let sock;
    try {
      sock = new WS(`${ticket.url}${ticket.url.includes('?') ? '&' : '?'}token=${encodeURIComponent(ticket.token)}`);
    } catch {
      ticket = null;
      return reconnectLater(id);
    }
    ws = sock;
    sock.onopen = () => {
      if (!alive(id) || ws !== sock) return;
      backoff = minBackoffMs;
      startPing(sock);
      scheduleRenew(id);
      setPushConnected(true);
    };
    sock.onmessage = (ev) => {
      if (alive(id) && ws === sock) handlePushFrame(ev.data);
    };
    sock.onclose = () => {
      if (ws !== sock) return;
      ws = null;
      ticket = null; // 断开后旧票作废，重连换新票
      clear('ping');
      clear('renew');
      if (!alive(id)) return;
      setPushConnected(false);
      reconnectLater(id);
    };
    sock.onerror = () => {
      try { sock.close(); } catch { /* onclose 收尾 */ }
    };
  }

  function reconnectLater(id) {
    if (!alive(id)) return;
    clear('reconnect');
    const delay = Math.min(backoff, maxBackoffMs) * (0.8 + random() * 0.4);
    backoff = Math.min(backoff * 2, maxBackoffMs);
    timers.reconnect = st(() => { timers.reconnect = null; connect(); }, delay);
  }

  function startPing(sock) {
    clear('ping');
    const tick = () => {
      timers.ping = st(() => {
        try { if (sock.readyState === 1) sock.send('ping'); } catch { /* onclose 收尾 */ }
        tick();
      }, pingMs);
    };
    tick();
  }

  /** events 只在握手时验票：静默换一张备用，下次重连直接用，不断开当前流 */
  function scheduleRenew(id) {
    clear('renew');
    const ttl = ticket?.ttlMs || 15 * 60_000;
    timers.renew = st(async () => {
      timers.renew = null;
      try {
        const t = await client.watchTicket();
        if (alive(id)) { ticket = t; scheduleRenew(id); }
      } catch { /* 下次重连再换 */ }
    }, Math.max(30_000, ttl * 0.8));
  }

  function disconnect() {
    clear('ping');
    clear('renew');
    clear('reconnect');
    const sock = ws;
    ws = null;
    ticket = null;
    if (sock) {
      try { sock.close(1000); } catch { /* ignore */ }
    }
  }

  /* ------------------------------------------------------------ 生命周期 */

  async function begin() {
    const id = ++runId;
    running = true;
    backoff = minBackoffMs;
    let cred;
    try {
      cred = await client.credentials.get();
    } catch (err) {
      if (alive(id)) { store.setError(errCode(err)); onEvent({ type: 'credential_error', error: errCode(err) }); }
      return;
    }
    if (!alive(id)) return;
    store.setIdentity(cred.identityKey);
    if (active) await openSync(id);
    else await syncUnread();
    if (!alive(id)) return;
    connect();
    schedule();
  }

  async function openSync(id) {
    await pollNow();
    if (!alive(id)) return;
    const key = store.getState().identityKey;
    if (reconcileFeedbackOnOpen && store.getState().feedbackEnabled) {
      client.feedbackList()
        .then((map) => { if (alive(id)) store.reconcileFeedback(map, { identityKey: key }); })
        .catch(() => {});
    }
  }

  function setActive(next) {
    next = next !== false;
    if (next === active) return;
    active = next;
    clear('poll');
    clear('typing');
    if (!running) return;
    if (active) {
      // 展开即读：本地先清角标，poll 拉到回复后服务端也清零
      store.setUnread(0);
      openSync(runId);
      syncTyping();
    } else {
      syncUnread();
    }
    schedule();
  }

  async function restart() {
    disconnect();
    clearAll();
    running = false;
    return begin();
  }

  function onVisibility() {
    if (!running) return;
    // 可见性改变了节奏（隐藏时 hiddenPollMs / 不轮询 typing）：旧定时器作废重排
    clear('poll');
    clear('typing');
    if (visibility.isVisible()) {
      if (active) {
        pollNow();
        syncTyping();
      } else {
        syncUnread();
      }
    } else {
      schedule();
    }
  }

  /* ------------------------------------------------------------ 用户动作 */

  async function send({ text = '', files = [], lang, meta } = {}) {
    const id = runId;
    const key = store.getState().identityKey;
    const clientId = `c${Date.now().toString(36)}${(++clientSeq).toString(36)}`;
    store.addPending({ clientId, text, files });
    try {
      const r = await client.send({ text, files, lang, meta });
      // 回执属于发起时的身份，且那时的身份仍是当前身份，才转正
      if (r.identityKey !== key || store.getState().identityKey !== key) {
        store.dropPending(clientId);
        throw new SupportApiError('identity_changed');
      }
      store.resolvePending(clientId, { id: r.id, identityKey: key });
      if (alive(id)) pollNow();
      return { ok: true, id: r.id, clientId };
    } catch (err) {
      store.failPending(clientId, errCode(err));
      throw err;
    }
  }

  async function changeMode(action, { lang } = {}) {
    const key = store.getState().identityKey;
    store.bumpModeSeq(); // 在途的旧 poll 不得覆盖这次动作的结果
    try {
      const r = action === 'handoff' ? await client.handoff({ lang }) : await client.aiResume({ lang });
      store.setMode(r.mode, { identityKey: key });
      pollNow();
      return r;
    } catch (err) {
      const mode = err?.body?.mode;
      if (mode) store.setMode(mode, { identityKey: key }); // 409 带当下模式：按钮直接校正
      throw err;
    }
  }

  /** 服务端确认才改状态（与 CCDub 官网线上一致）。返回最终 feedback */
  async function rate(msgId, rating, { reason, comment } = {}) {
    const key = store.getState().identityKey;
    if (store.getState().feedbackBusy[msgId]) return null;
    store.setFeedbackBusy(msgId, true);
    try {
      const r = await client.feedback({ msgId, rating, reason, comment });
      store.setFeedback(msgId, r.feedback, { identityKey: key });
      return r.feedback;
    } catch (err) {
      const code = errCode(err);
      if (code === 'unavailable') store.disableFeedback();
      else if (code === 'not_found' || code === 'not_rateable') store.markUnrateable(msgId);
      throw err;
    } finally {
      store.setFeedbackBusy(msgId, false);
    }
  }

  return {
    store,
    client,
    start() {
      if (running) return Promise.resolve();
      if (!unsubVisibility) unsubVisibility = visibility.onChange(onVisibility);
      return begin();
    },
    stop() {
      running = false;
      runId++;
      disconnect();
      clearAll();
      if (unsubVisibility) { unsubVisibility(); unsubVisibility = null; }
    },
    /** 登录 / 登出 / 切账号：丢掉凭证缓存与全部状态，按新身份重来 */
    resetIdentity() {
      client.credentials.clear?.();
      store.setIdentity(null);
      return restart();
    },
    refresh: () => (active ? pollNow() : syncUnread()),
    setActive,
    isActive: () => active,
    syncTyping,
    handlePushFrame,
    setPushConnected,
    send,
    requestHuman: (opts) => changeMode('handoff', opts),
    resumeAi: (opts) => changeMode('resume', opts),
    rate,
    upload: (blob) => client.upload(blob),
    /** 面板没打开时查未读（扩展 background / 官网 FAB）；打开着就不用，poll 会清未读 */
    async refreshUnread() {
      const key = store.getState().identityKey;
      const n = await client.unread();
      store.setUnread(n, { identityKey: key });
      return n;
    },
    canRequestHuman: () => store.getState().supportMode === SUPPORT_MODES.AI,
    canResumeAi: () => store.getState().supportMode === SUPPORT_MODES.HUMAN_REQUESTED,
  };
}

function errCode(err) {
  return err?.code || err?.message || 'error';
}

function defaultVisibility() {
  const doc = globalThis.document;
  if (!doc) return { isVisible: () => true, onChange: () => () => {} };
  return {
    isVisible: () => doc.visibilityState !== 'hidden',
    onChange(cb) {
      doc.addEventListener('visibilitychange', cb);
      return () => doc.removeEventListener('visibilitychange', cb);
    },
  };
}
