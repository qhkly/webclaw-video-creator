/**
 * 文案键与兜底文案。各产品自带 70+ 语言的翻译（CCDub 官网 support.* / 扩展 _locales /
 * WebClaw support_*），本包只定义「UI 需要哪些语义」和 en/zh 兜底，宿主用 resolve 映射到自己的键。
 */

import { FEEDBACK_REASONS } from './protocol.js';

export const MESSAGE_KEYS = Object.freeze([
  'title', 'empty', 'placeholder', 'send',
  'roleAi', 'roleHuman', 'eventRequestHuman', 'eventResumeAi', 'eventHumanAck',
  'typingAi', 'typingHuman',
  'modeAi', 'modeHuman', 'modeHumanRequested', 'toHuman', 'toAi', 'humanWaitHint',
  'rateUp', 'rateDown', 'reasonTitle', 'commentPlaceholder',
  ...FEEDBACK_REASONS.map((r) => `reason_${r}`),
  'errorTooFast', 'errorDailyQuota', 'errorTooLong', 'errorTooLarge', 'errorSend', 'errorReauth', 'errorUnavailable',
  'errorTooManyFiles', 'errorFileType', 'errorFileRejected', 'newMessages',
  'unread',
  'open', 'close', 'attach', 'retry', 'sending', 'submit', 'filesChosen', 'attachment', 'remove', 'uploading',
]);

export const FALLBACK = Object.freeze({
  en: {
    title: 'Support', empty: 'Ask us anything.', placeholder: 'Type a message…', send: 'Send',
    roleAi: 'AI assistant', roleHuman: 'Support agent',
    eventRequestHuman: 'You asked for a human agent', eventResumeAi: 'You returned to the AI assistant',
    eventHumanAck: 'A human agent will reply here',
    typingAi: 'AI assistant is working on it…', typingHuman: 'Support agent is typing…',
    modeAi: 'AI assistant', modeHuman: 'Human agent', modeHumanRequested: 'Waiting for a human agent',
    toHuman: 'Talk to a human', toAi: 'Back to AI assistant',
    humanWaitHint: 'A human agent may take a while to reply. You can try the AI assistant first — it may solve your problem faster.',
    rateUp: 'Helpful', rateDown: 'Not helpful', reasonTitle: 'What went wrong?', commentPlaceholder: 'Tell us more (optional)',
    reason_wrong: 'Incorrect', reason_irrelevant: 'Off-topic', reason_unclear: 'Hard to understand',
    reason_not_solved: 'Did not solve my problem', reason_want_human: 'I want a human', reason_other: 'Other',
    errorTooFast: 'You are sending too fast. Please wait a moment.',
    errorDailyQuota: 'Daily limit reached. Please try again later.',
    errorTooLong: 'Message is too long.', errorTooLarge: 'File is too large.', errorSend: 'Could not send. Please retry.',
    errorReauth: 'Session expired. Please retry.', errorUnavailable: 'Temporarily unavailable.',
    errorTooManyFiles: 'You can attach at most {max} file(s) per message.', errorFileType: 'This file type is not supported.',
    errorFileRejected: 'This file cannot be attached.', newMessages: '{count} new message(s) ↓',
    unread: '{count} unread',
    open: 'Open support chat', close: 'Close', attach: 'Attach image', retry: 'Retry', sending: 'Sending…',
    submit: 'Submit', filesChosen: '{count} file(s) attached', attachment: 'Attachment', remove: 'Remove', uploading: 'Uploading…',
  },
  zh: {
    title: '客服', empty: '有问题随时问我们。', placeholder: '输入消息…', send: '发送',
    roleAi: 'AI 客服', roleHuman: '人工客服',
    eventRequestHuman: '你请求了人工客服', eventResumeAi: '你返回了 AI 客服', eventHumanAck: '人工客服会在这里回复你',
    typingAi: 'AI 客服正在处理…', typingHuman: '人工客服正在输入…',
    modeAi: 'AI 客服', modeHuman: '人工客服处理中', modeHumanRequested: '等待人工客服',
    toHuman: '转人工', toAi: '返回 AI 客服',
    humanWaitHint: '人工客服回复可能需要一些时间，你可以先试试 AI 客服，也许能更快解决问题。',
    rateUp: '有帮助', rateDown: '没帮助', reasonTitle: '哪里不好？', commentPlaceholder: '补充说明（可选）',
    reason_wrong: '回答错误', reason_irrelevant: '答非所问', reason_unclear: '看不懂',
    reason_not_solved: '没解决问题', reason_want_human: '想找人工', reason_other: '其他',
    errorTooFast: '发送太快了，请稍候再试。', errorDailyQuota: '今日次数已用完，请稍后再试。',
    errorTooLong: '消息太长。', errorTooLarge: '文件太大。', errorSend: '发送失败，请重试。',
    errorReauth: '会话已过期，请重试。', errorUnavailable: '暂时不可用。',
    errorTooManyFiles: '每条消息最多添加 {max} 个附件。', errorFileType: '不支持该文件类型。',
    errorFileRejected: '该文件无法添加。', newMessages: '{count} 条新消息 ↓',
    unread: '{count} 条未读',
    open: '打开在线客服', close: '关闭', attach: '添加图片', retry: '重试', sending: '发送中…',
    submit: '提交', filesChosen: '已添加 {count} 个文件', attachment: '附件', remove: '移除', uploading: '上传中…',
  },
});

/** 错误码 → 文案键 */
export function errorMessageKey(code) {
  switch (code) {
    case 'too_fast': return 'errorTooFast';
    case 'daily_quota': return 'errorDailyQuota';
    case 'too_long': return 'errorTooLong';
    case 'too_large': return 'errorTooLarge';
    case 'bad_signature': case 'bad_ticket': case 'ticket_required': return 'errorReauth';
    case 'unavailable': case 'watch_disabled': return 'errorUnavailable';
    default: return 'errorSend';
  }
}

/**
 * @param {(key: string, vars?: object) => (string|undefined|null)} [lookup] 宿主翻译函数；返回空则兜底
 * @param {string} [lang]
 */
export function createTranslator(lookup, lang = 'en') {
  const base = FALLBACK[String(lang).toLowerCase().startsWith('zh') ? 'zh' : 'en'];
  return (key, vars = {}) => {
    const hit = lookup ? lookup(key, vars) : null;
    const s = typeof hit === 'string' && hit && hit !== key ? hit : base[key] ?? FALLBACK.en[key] ?? key;
    return s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String(vars[k]) : m));
  };
}
