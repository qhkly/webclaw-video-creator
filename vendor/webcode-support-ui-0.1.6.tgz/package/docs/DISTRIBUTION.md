# 分发与跨仓库消费

## 现状（2026-10-20）

- 包名 `@webcode/support-ui`，纯 ESM、零运行时依赖，`private: true`（防误 `npm publish`）。
- 本仓库**没有配置 git remote，也没有可用的私有 npm registry**；未经授权不创建仓库、不 push、不 publish。**远端发包 = 阻塞项**，需人工选定下面方案 B/C 之一。
- 当前唯一已验证、可复现的分发物：`npm pack` 生成的 tarball（`webcode-support-ui-<version>.tgz`，≈78 kB，21 个文件：`src/`、`dist/webcode-support.js`、docs、README）。`prepack` 会自动重建 `dist/`。

## 产出与验证

```bash
cd ui && npm ci
npm pack                 # → webcode-support-ui-0.1.0.tgz
npm run test:pack        # 隔离消费者 smoke（不联网）
SMOKE_NEXT=1 npm run test:pack   # 额外：真实 Next.js 15 build（需联网装 next）
```

smoke 覆盖：tarball 内容（无 test/demo）、空目录 `npm install` tgz、零运行时依赖、12 个 exports 在**无 DOM 的 Node**（= SSR/RSC）下 import、`mount()` 无 DOM 时显式抛错、未导出内部路径被拒、`dist` IIFE 在 jsdom 可执行且无密钥代码、bundler 解析 exports、（可选）真实 Next build。

## 消费方案（按推荐顺序）

| 方案 | 做法 | 状态 |
|---|---|---|
| A. 提交 tgz 到消费仓库 | 把 `vendor/webcode-support-ui-0.1.0.tgz` 放进消费仓库，`"@webcode/support-ui": "file:vendor/webcode-support-ui-0.1.0.tgz"`；lockfile 带 integrity，本地/CI/Vercel 均可 `npm ci` | **现在即可用**，无需任何远端 |
| B. 私有 Git 仓库的 Release 资产 | 人工创建/授权仓库后，把 tgz 作为 tag 的 release asset，依赖写 asset URL（需 CI 带 token） | 阻塞：无 remote，需所有者决定 |
| C. 私有 npm registry（GitHub Packages 等） | 去掉 `private`，加 `publishConfig.registry`，消费方配 `.npmrc` + token | 阻塞：无 registry/凭证 |

不推荐 `git+ssh://…#subdir`：npm 不支持子目录依赖（本包在 `ui/`）。

版本锁定：每次协议变化顺序为 Worker → 契约测试 → 改 `ui/package.json` version → `npm pack` → 各端升级 tgz；0.x 期间各端锁定具体 tgz 文件名 + lockfile integrity。

## Next.js 消费示例

不需要 `transpilePackages`（发布的是已是标准 ESM 的源码，无 JSX、无 TS）。Widget 依赖 DOM，只能在浏览器执行：

```js
// app/support-widget.js
'use client';
import { useEffect } from 'react';

export default function SupportWidget() {
  useEffect(() => {
    let w;
    let dead = false;
    import('@webcode/support-ui/widget').then((m) => {
      if (!dead) w = m.mount({ app: 'ccdub', auth: 'session' /* 其余见 README */ });
    });
    return () => { dead = true; w?.destroy?.(); };
  }, []);
  return null;
}
```

- 纯核心（`@webcode/support-ui`、`/protocol`、`/client`、`/store`、`/session`、`/react`）可在服务端 import，不触碰 DOM；`createSupportSession().start()` 才开始联网，放进 `useEffect`。
- 不想打进 bundle：`import '@webcode/support-ui/embed'` 不要用；改用 `@webcode/support-ui/dist/webcode-support.js` 复制到 `public/support/`，页面 `<script defer data-app=…>`（见 README）。
- `./embed` 是有副作用入口（`sideEffects` 已声明），只在浏览器 import。

## 其他团队接入步骤

1. 拿到 tgz（本地 `cd ui && npm pack`，或由所有者提供）；放进自己仓库 `vendor/`，`npm i file:vendor/…tgz`。
2. 凭证只来自自家服务端（`/api/support/session` 或 `/api/support/token`），不要放任何密钥进前端。
3. 组件按上面示例做 client-only 加载；CI 里跑 `npm ci && next build`。
4. 见 [MIGRATION.md](MIGRATION.md) 对应端的清单。
