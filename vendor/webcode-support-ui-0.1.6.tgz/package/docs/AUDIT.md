# 统一客服第一阶段：只读审查（2026-10-19）

审查对象：support Worker（权威协议）、CCDub 官网、CCDub 扩展、WebClaw 官网、WebClaw Store、AI Studio 官网、
AI Studio 桌面端、CCDub Desktop。**本阶段未修改任何线上工程，未推送、未部署。**

## 1. 权威协议：support Worker

来源：`tools/support-worker/src/index.js`（本仓库 HEAD 9cedab95，含 typing 推送 c54a090e、评价 08fccd70）。
线上谱系领先 master，见 memory「support Worker 发布谱系」；本包契约测试同时在 HEAD 与
`feat/support-ai-studio-ticket-auth`（02644b9b，票据鉴权，未合并未部署）两版 Worker 上通过。

| 端点 | 方法 | 鉴权位置 | 关键响应字段 |
|---|---|---|---|
| `/api/send` | POST JSON | body `app,uid,ts,sig` / Bearer | `id, dedup?, translated`；错误 `too_fast`/`daily_quota`/`too_long`/`empty` |
| `/api/poll?since=` | GET | query / Bearer | `messages[{id,role,text,files,at,event?,rateable?,feedback?}]`, `status`, `human_requested`(旧), `support_mode`, `typing`, `typing_rev`, `typing_push`, `feedback_enabled`, `schedule` |
| `/api/handoff` | POST | body | `{ok, mode, already?}` 幂等 |
| `/api/ai-resume` | POST | body | `{ok, mode:'ai'}`；409 `{error:'human_takeover'|'not_resumable', mode}` |
| `/api/feedback` | POST | body | `msg_id, rating:'up'|'down'|null, reason?, comment?(≤300)` → `{ok,msg_id,feedback}`；404/409/429/503 |
| `/api/feedback` | GET | query | `{feedback:[{msg_id,rating,reason,comment,at}]}` 最近 200 条 |
| `/api/typing` | GET | query | `{typing:{actor,ttl_ms}|null, rev, typing_push}` |
| `/api/unread` | GET | query | `{unread}` |
| `/api/watch-ticket` | GET | query | `{url,token,ttlMs}`；未配置 501 `watch_disabled` |
| `/api/upload` | POST 原始字节 | query（含 token） | `{key,mime}`；413/415 |
| `/file/<key>` | GET | query / Bearer | 附件；归属校验 403 |

- 角色：`user` / `ai` / `admin`(人工)。`event`：`request_human`/`resume_ai`（user）、`human_ack`（ai，系统确认，不可评价）。
- 模式：`ai` / `human_requested`（用户自己请求，可返回 AI）/ `human`（管理员接管，不可返回）。
- 点踩原因（6 种，顺序固定）：`wrong, irrelevant, unclear, not_solved, want_human, other`。
- 推送（events.qhkly.com）：`{type:'support_cursor', lastId}`（连上即发；可能是上一条 typing 帧，忽略其 typing）、
  `{type:'support_notify', lastId}`、`{type:'support_notify', kind:'typing', lastId:0, typing, rev}`；`ping`→`pong`。
  帧不含邮箱/正文；内容一律回 `/api/poll` 取。
- 旧签名：`sha256(app_uid_ts + secret)`，±5 分钟；`SIGN_SECRET_<APP>` 未配时回退共享 `SIGN_SECRET`。
- 票据（分支）：`Authorization: Bearer <ES256 JWT>`，`iss/aud=support.qhkly.com/app/sub(u_|a_+22)/tier/plan/email/iat/exp/jti`，
  TTL ≤ 900s；`SUPPORT_TICKET_TENANTS` 按租户 `dual|ticket_only`；票据请求不看 `uid/ts/sig/token`；
  请求显式带的 `app` 必须与票据一致；CORS 需放行 `Authorization`（分支已改）。

## 2. 各端差异

| 产品 (app) | 位置 / 状态 | 凭证 | 浏览器/客户端是否持有共享密钥 | 推送 | 评价 | 转人工/返回 AI | 账号切换 |
|---|---|---|---|---|---|---|---|
| CCDub 官网 (ccdub / ccdub-desktop) | dub_precedent `main` eea6312，**已上线** | 同源 `GET /api/support/session` → `{app,origin,uid,ts,sig,ttlMs:240000,loggedIn}`；uid=NextAuth 邮箱或 httpOnly `ccdub_support_uid`(anon-…@qhkly.com) | 否（`SUPPORT_SIGN_SECRET[_DESKTOP]` 在服务端） | 自建 WS，1s→30s 退避，30s ping，80% TTL 换票；断线 5s poll；typing 2s 兜底 | 服务端确认才改；不发原因；`GET /api/feedback` 对账 | 有；409 用 mode 校正 | **缺口**：uid 变化不清 messages/since |
| CCDub 扩展 (ccdub) | 本仓库 packages/air，已发版 | content 自签 | **是**：`'ccdub-support-v1'` 打包（supportClient.js:26、background.js:939） | background 持有 WS，帧经 runtime 消息转发；面板断线 60s poll | 乐观+回滚；down 先提交、原因二次提交 | 有；modeSeq 防竞态 | 无显式重置；uid 是 sync `userEmail`（匿名随机） |
| CCDub Desktop | ccdub-desktop `main` | 内嵌 webview 打开 `/contact?openSupport=1&product=desktop`，不持密钥 | 否 | 走官网面板 | 同官网 | 同官网 | ef117c0（分支）登录/登出重置 webview |
| WebClaw 官网 (webclaw) | webclaw-platform 本地 main c3094d8，**937907f/c3094d8 未 push** | session 端点 + feedback/handoff 同源服务端代理 | 否 | 无 WS；5s/30s poll；typing 2s | 6 种原因 | 有（代理） | 服务端定 uid |
| WebClaw Store (store) | webclaw-store main b20770d（已部署） | session 端点，浏览器直连 Worker（刻意：按 IP 限流） | 否（但 .env.example 注明与扩展共用同一密钥） | 自建 WS + 2s typing 兜底 + 5s poll | 6 种原因 + 备注 | 有 | 服务端定 uid |
| AI Studio 官网 (ai-studio) | webcode-ai-studio-web 仅分支 feat/checkout-via-billing-center，**未上线** | session 端点（旧签名）；`/api/support/token` 未实现 | 否 | WS + 5s poll | 无 | 无 | uid 取旧 `webclaw_token` 邮箱（契约要求废弃） |
| AI Studio 桌面 (ai-studio) | webcode-ai-studio `main` 已发版；票据版在 chatgpt/7dce4342 | main：Rust 自签；分支：Bearer 票据 | **是（main）**：`support_commands.rs:23` 硬编码同一共享密钥 | Rust 侧 WS | 分支有 | 分支有 | 分支 `reset_for_logout` |

## 3. 可安全抽取范围（本包已含）

- 协议常量与规范化（含旧服务端降级）、推送帧解析。
- HTTP 客户端：旧签名放 query/body、票据只放 Authorization；401 强制重取凭证并重试一次；票据凭证不拼附件 URL。
- 凭证提供方：同源 session、票据、宿主自取（扩展/桌面 IPC）；**包内无任何签名实现**，凭证出现密钥形字段即拒绝。
- 状态库：按 `app|uid` 分桶的账号隔离、id 去重、乐观消息按回执 id 转正、modeSeq、typing rev、评价忙碌位。
- 会话编排：推送/兜底轮询/退避重连/换票不断流/可见性/身份变化自动重来；`push: websocket|external|none`。
- i18n 语义键 + en/zh 兜底；`(N)` 标题前缀（与桌面外壳逐字一致）；React 轻适配（React 由宿主注入）。

**不抽取**（产品专属，留在各端）：签名/票据签发（服务端）、扩展的共享密钥签名（既有安全债，迁移目标是票据）、
附件压缩/录屏（各端媒体限制不同）、排班展示、站点公告、具体 UI 组件与样式、background 未读角标。

## 4. 部署兼容性

- 本包是**新增独立目录**，不进 npm workspaces（根 `workspaces` 只含 `packages/*`），不改任何构建产物、Worker、站点。
- 协议只读不写：不要求 Worker 任何改动；旧服务端（无 support_mode/typing_push/feedback_enabled）自动降级。
- 推送节奏与线上 CCDub 官网一致；不会让 WS 因凭证刷新每 4 分钟重连。
- 票据路径依赖未合并的 Worker 分支 + `/api/support/token`；未配置时 ai-studio 仍可走 session 端点。
- **保留 CCDub 已上线稳定性**：CCDub 官网/扩展本阶段不迁移，迁移按 MIGRATION.md 分阶段、可回滚。

## 5. 发现的问题（未修，列入迁移）

1. CCDub 官网：uid 变化（页内登录/登出）不清消息与 since 游标 → 新账号会看到旧账号消息、游标错位。本包已修（store 身份分桶）。
2. 共享密钥 `ccdub-support-v1` 仍在扩展与 AI Studio 桌面 main 中；生产未配任何 `SIGN_SECRET_<APP>`，所有旧签名租户可被伪造。
3. WebClaw 官网 937907f/c3094d8 未 push；AI Studio 官网客服未上 main。
4. 官网 FAB 与面板各自取 session、各开一条 WS；共用一个 session 实例可减半连接（Widget 已这样做）。
5. （第二阶段，浏览器端到端发现）票据分支 Worker 的 `/file/<key>` GET 响应缺 CORS 头：
   票据只能放 Authorization 头 → 只能 `fetch` 取附件 → 跨源被浏览器拦截。旧签名靠 `<img src>` 不受影响。
   位置：`tools/support-worker/src/files.js` `handleGet`（票据分支 02644b9b）。
   **已修（第二阶段）**：票据分支已并入本线，`src/index.js` 用户侧 `/file`、`/img` 路由统一补 CORS（含 401/403/404、
   暴露 Content-Range、票据响应 `Vary: Authorization`），浏览器用例由 todo 转为必过。
6. （第二阶段）`/api/poll` 只要返回了非用户消息就清零 `unread_user`：任何「面板收起时也 poll」的客户端都会把回复吞成已读。
   Widget 收起态只调 `/api/unread`；迁移各端时不要在收起态保留 poll。
