# 迁移清单

原则：一次只迁一个端；每步可单独回滚（保留旧组件到下一个版本）；**先迁未上线/风险最低的，CCDub 最后**。
每一步都要求：本包 `npm test` + `npm run test:browser` + `npm run lint` 全绿 + 该端原有测试全绿 + 线上 bundle 验证（grep `api/support/session|api/typing`）。

## 接入方式选择（第二阶段新增 Widget）

| 端 | 推荐接入 | 凭证 | 推送 | 宿主要提供的 |
|---|---|---|---|---|
| 网站（无自有客服 UI） | `dist/webcode-support.js` 一行 script | `data-auth=session|ticket` | websocket | 同源凭证端点；主题 `data-*`；可选 `t` 翻译 |
| 网站（已有 React 面板、要保留 UI） | 核心 + `react` 适配，只替换状态/轮询 | 同上 | websocket | 现有组件改读 `useSupportState` |
| 桌面 WebView | `createSupportWidget({mode:'inline'})` | `hostCredentials`（原生 IPC 签票） | websocket | IPC 命令；`titleBadge` 或 `onUnreadChange` 回传未读 |
| 浏览器扩展 | 核心 + 自有面板（Shadow DOM 已有） 或 Widget inline | `customCredentials`（过渡）→ 票据 | external：`bindExtensionPush` | background 现有三种广播 |

Widget 收起态只查未读（不 poll），启动按钮与面板共用 session —— 迁移后官网 FAB + 面板两条 WS 合成一条。

## 第二阶段交付状态（2026-10-20）

- Worker 票据鉴权（原 `feat/support-ai-studio-ticket-auth` 19e153dc+02644b9b）已按原提交 cherry-pick 进本线
  （master 自分叉点 08fccd70 之后没改过 `tools/support-worker`，无冲突），未整树覆盖；1101 原子发送、评价、typing 推送原样保留。
- 附件跨域缺口已修：用户侧 `/file`、`/img` 全部响应带 CORS（含 401/403/404），票据响应 `Vary: Authorization`。
- 本包票据契约 / 浏览器用例不再依赖 `SUPPORT_WORKER_SRC`：同仓库 Worker 即带 `src/auth.js`，原 5 个跳过与 1 个 todo 全部转为必过；
  新增过期换票、换票只重试一次、跨账号附件 403 + CORS、dual 旧签名兼容 / 冒用票据形 uid 拒绝、ticket_only 拒旧签名。
- **均未部署**：生产 Worker 仍是旧签名；011 未在生产执行；`SUPPORT_TICKET_TENANTS` 未配置。

## 移交给其他工程的契约（本仓库不改它们）

### AI Studio 官网（webcode-ai-studio）：`GET /api/support/token?app=ai-studio`

权威文档：webcode-ai-studio `docs/support-ticket-contract.md`；共享向量 `tools/support-worker/support-ticket-contract.vectors.json`。

- 同源调用，靠官网自己的会话 cookie（桌面端由原生侧带登录 token 调用后经 IPC 转给页面）。响应 `Cache-Control: no-store`。
- 响应 `200 {ticket, uid, expiresAt}`：`expiresAt` 为**秒**；`uid` 与票据 `sub` 相同。未登录可发匿名票（`a_…`，无 email）。
- 票据 = ES256 JWT，header `{alg:'ES256', typ:'JWT', kid}`；claims
  `iss='ai-studio-web'`、`aud='support.qhkly.com'`、`app='ai-studio'`、`sub`、`tier`（`user`/`anon`，与 sub 前缀一致）、
  `plan`（`free`/`paid`）、`email`（仅 user，官网已验证的邮箱）、`iat`、`exp`（`exp−iat ≤ 900`）、`jti`。
- `sub = 前缀 + base64url_nopad(HMAC-SHA256(uidKey, 'v1|'+app+'|'+kind+'|'+id))[0:22]`：同账号恒定、不可逆、不含邮箱；
  `uidKey` 与签名私钥都只在官网服务端（环境变量），**不得**出现在任何前端 bundle、桌面安装包或响应里。
- `GET /api/support/public-key` → `{keys:[JWK]}`（`kty:EC, crv:P-256, kid, alg:ES256, use:sig`，只含 x/y），运维据此配 Worker。
- 切账号 / 登出：官网下一次 `/api/support/token` 就返回新 sub；前端调 `session.resetIdentity()`（Widget 由 `data-auth` 页的账号变化触发）。
- 验收：在官网仓库跑共享向量（uid 与票据两组）；用本包 `demo/studio.html` 的同源签发作参考实现（`test/workerHarness.mjs ticketIssuer`，仅测试用）。

### AI Studio 桌面：IPC `support_ticket`

- 原生侧带登录 token 调官网 `/api/support/token`，把 `{ticket, uid, expiresAt}` 原样交给页面；页面
  `hostCredentials({ app: 'ai-studio', request: () => invoke('support_ticket') })`。
- 移除 `support_commands.rs` 里的共享密钥；`hostCredentials` 会拒收任何密钥形字段。

### support Worker 运维（生产 D1 / secret，需人工审查后执行）

1. 发布前核对线上版本 vars 与表（线上谱系曾领先 master）；本线 `tools/support-worker` 内容已含线上功能（8158cbb9 起）+ 1101/评价/typing 推送 + 票据。
2. 生产 D1：`PRAGMA table_info(threads)` 无 `legacy_uid` 时跑 `migrations/011_thread_legacy_uid.sql`（不可重跑）。
3. 部署（不配 `SUPPORT_TICKET_TENANTS` = 行为不变）；清 `ai-studio` 的 `push_token` 与 `rate` 表 `tok:ai-studio:%`。
4. 官网 token/public-key 上线后 `wrangler secret put SUPPORT_TICKET_TENANTS`（`mode:"dual"`）。
5. 客户端切票据、白名单验收；`support_legacy_auth` 日志降下来后改 `ticket_only`。

## 各端迁移依赖一览（核对时间 2026-10-20）

| 端 | 本包侧 | 宿主仓库要做的 | Worker 要做的 | 能否现在开始 |
|---|---|---|---|---|
| AI Studio 官网 | 就绪（studio.html 票据 + 附件端到端必过） | 实现 `/api/support/token` + `/api/support/public-key`；客服分支并入 main | 代码已就绪（票据 + 附件 CORS）；待部署 + 跑 011 + 配 `SUPPORT_TICKET_TENANTS` | 宿主侧可开工；上线卡 Worker 发布 |
| AI Studio 桌面 | 就绪（hostCredentials + inline） | 发版 chatgpt/7dce4342；IPC 暴露 `support_ticket` | 同上 | 卡 Worker 发布 |
| WebClaw Store | 就绪 | 用 Widget 或核心替换 `lib/support-*` | 配 `SIGN_SECRET_STORE`（与站点原子切换） | 可开工 |
| WebClaw 官网 | 就绪 | 先 push 937907f/c3094d8；同源代理保留或改直连 | 配 `SIGN_SECRET_WEBCLAW` | 可开工（推送属该仓库发布流程） |
| CCDub 官网 | 就绪（ember/aurora 演示同一 session 协议） | `/contact` 灰度；`resetIdentity` 修切号 bug；文案 `support.*` 经 `t` 注入 | 无（旧签名照用） | 可开工，灰度上线 |
| CCDub 扩展 | 就绪（`bindExtensionPush`） | 面板换编排；签名暂留原处 | 扩展换票方案（含匿名票）后才能去掉共享密钥 | 编排可开工；去密钥卡服务端设计 |

## 0. 包的分发（先决）

- [x] 已有独立工程 `webcode-support`（`ui/` 即本包）；旧独立工程 `webcode-support-ui` 已删除，勿重建。分发方案见 [DISTRIBUTION.md](DISTRIBUTION.md)：`npm pack` tgz（`file:` 依赖，现在可用）；远端仓库/registry 发包待所有者授权。
- [x] 各端 Next.js：无需 `transpilePackages`（发布物是标准 ESM），Widget 须 client-only 加载；已由 `npm run test:pack`（含可选真实 Next build）验证。
- [ ] 版本：0.x 期间各端锁定 commit；协议变化先改 Worker → 再改本包契约测试 → 再发包。

## 1. AI Studio 官网（未上线，风险最低）

- [ ] 实现 `/api/support/token`（契约 §3），**不**在前端放任何密钥；`ticketCredentials({ app: 'ai-studio' })`。
- [ ] 过渡期可先用 `siteSessionCredentials({ expectApp: 'ai-studio' })`，但 uid 不能再取 `webclaw_token` 邮箱。
- [ ] 附件用 `client.fetchFile(key)` → blob URL（票据不进 URL；Widget 已内置）。
- [x] Worker 附件 GET 补 CORS（本线已修，浏览器用例必过）。
- [ ] Worker：部署本线 → 先跑 011 → 配 `SUPPORT_TICKET_TENANTS`(dual) → 清 ai-studio push_token（见上文「support Worker 运维」）。
- [ ] 稳定后 ticket_only，删 ai-studio 的 `/api/support/session` 与 `SUPPORT_SIGN_SECRET`。

## 2. AI Studio 桌面

- [ ] 发版 chatgpt/7dce4342（Bearer 票据），移除 `support_commands.rs` 硬编码密钥。若 UI 是 web 技术，可用 `customCredentials` 从 IPC 拿票据。
- [ ] ticket_only 之后旧版桌面端失效 → 需强制升级窗口。

## 3. WebClaw Store

- [ ] 替换 `lib/support-*.ts` 的协议/轮询/WS 部分为 `createSupportSession({ push: 'websocket' })`，保留现有 UI 与 dict 文案（`createTranslator(dict lookup)`）。
- [ ] 保持浏览器直连 Worker（按用户 IP 限流的原因不变）。
- [ ] 配 `SIGN_SECRET_STORE`（Worker）与 Store 服务端 `SUPPORT_SIGN_SECRET` **原子同步**切换，解除与扩展共用密钥。

## 4. WebClaw 官网

- [ ] 先 push 937907f/c3094d8（属该仓库自身发布流程，本任务未做）。
- [ ] 其同源代理（feedback/handoff）保留：以自定义 `fetch` 把这两个端点改写到 `/api/support/*`，其余直连；或全部直连。
- [ ] 开推送：`push: 'websocket'`（目前无 WS，2s typing 轮询可去掉）。
- [ ] `SIGN_SECRET_WEBCLAW` 原子切换。

## 5. CCDub 官网（已上线，稳定性优先）

- [ ] 以 `createSupportSession` 替换 SupportPanel 内的 poll/WS/typing/feedback 状态逻辑，**UI/文案键 `support.*` 不动**（70 语言）；
      或直接换 Widget：`t = (k, v) => intl.formatMessage(...)` 把语义键映射到 `support.*`，主题 `primary` 取官网品牌色、`colorScheme:'document'`。
- [ ] 保留：`credsMatchProduct` → `expectApp`；meta `{source:'web'|'desktop-web', product, page, ua, uiLang, email?}` 由宿主传 `send({meta})`；
      localStorage `ccdub_support_active` / `ccdub_support_token`（`getToken`）；`(N) ` 标题（`titleWithUnread`，逐字一致）；`dynamic(ssr:false)`。
- [ ] FAB 与面板共用一个 session 实例（减半 WS）。
- [ ] 修复账号切换：NextAuth 状态变化时调 `session.resetIdentity()`（同时修了现存的「旧消息残留 + 游标错位」）。
- [ ] 灰度：先 `/contact` 页（desktop webview 入口），观察一周，再首页与 (plain) 页。回滚 = 切回旧组件。
- [ ] `SIGN_SECRET_CCDUB` / `_CCDUB_DESKTOP` 不能单独切：扩展仍用共享密钥签 ccdub —— 见第 6 步。

## 6. CCDub 扩展（最后）

- [ ] 第一步只换编排：`createSupportSession({ push: 'external' })`，background 继续持有 WS，把
      `supportTypingEvent` / `supportNotify` / `supportWatchState` 喂给 `handlePushFrame` / `setPushConnected`；
      凭证 `customCredentials(() => background 签好的 legacy)` —— 签名仍在扩展原处（既有安全债，不进本包）。
- [ ] 评价交互（down 先提交、原因二次提交、乐观回滚）若要保持，在 UI 层包一层；本包默认服务端确认。
- [ ] 第二步（需服务端配合）：官网新增扩展可用的票据签发（以扩展登录态换票，匿名用户需设计匿名票），
      Worker 给 ccdub 开 dual → ticket_only，扩展移除 `ccdub-support-v1`。这是消除共享密钥的唯一路径。

## 7. 收尾

- [ ] 所有租户都不再依赖共享 `SIGN_SECRET` 后，从 Worker 移除共享回退（products.js signSecretFor）。
- [ ] 删除各端遗留的重复实现与测试桩。
