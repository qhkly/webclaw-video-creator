# @webcode/support-ui

support.qhkly.com 统一客服的**产品无关**前端：协议、凭证、HTTP 客户端、状态库、会话编排（核心），
加一个**框架无关的 Widget**（原生 DOM + Shadow DOM，一行 script 嵌入），以及 React / 桌面 WebView / 扩展 / 标题角标几个薄适配。
零运行时依赖、纯 ESM、无 JSX。

- 协议以 `worker` 为权威，契约测试在进程内跑**真实 Worker**。
- **不含任何签名代码，不接受任何密钥。** 浏览器只拿服务端签好的凭证（同源 session 或短期票据）。

分发/跨仓库消费见 [docs/DISTRIBUTION.md](docs/DISTRIBUTION.md)。审查结论见 [docs/AUDIT.md](docs/AUDIT.md)，各端迁移步骤见 [docs/MIGRATION.md](docs/MIGRATION.md)。

## 一行嵌入（网站）

```html
<script src="/support/webcode-support.js" defer
        data-app="ccdub" data-auth="session"
        data-primary="#e11d48" data-font="Inter, sans-serif" data-radius="16"
        data-icon="headset" data-color-scheme="document" data-lang="zh-CN" data-title-badge="true"></script>
```

- `npm run build` 产出 `dist/webcode-support.js`（IIFE，全局 `WebcodeSupport`，无依赖）。各站把它当静态资源放进自己的域名下。
- 凭证只来自本站**服务端**：`data-auth="session"` → 同源 `GET /api/support/session`（旧签名）；`"ticket"` → `GET /api/support/token?app=`（ES256 短期票据）。
  脚本不读、也不接受任何密钥；`data-*` 只认白名单字段，主题值全部校验后才写进 CSS。
- 程序化：`data-auto="false"` 后 `const w = WebcodeSupport.mount({ app, theme, lang, t, meta, ... })`。
- 附件（0.1.2）：`attachments: false | true | { accept, maxFiles, reserved, beforeUpload }`。默认只收图片、最多 6 个（服务端上限）；`accept` 同 input 语法（如 `'image/*,video/webm'`）；`reserved: n | () => n` 是宿主托盘已占名额，与 Widget 内选中的文件合计不超 `maxFiles`；`beforeUpload(file, ctx)` 在选择时调用：返回 `undefined`/`true` 接受原文件；返回 `false`（或抛错 / 其它非 Blob 值）拒绝，统一提示「该文件无法添加」，不会把回调的错误信息展示给用户；返回 `Blob`/`File` 则用它替换原文件上传（如去 EXIF 重绘，类型仍须满足 `accept`）。超额、类型不符、被拒都有明确提示，不静默截断。`.webm` / `.mp4` 附件渲染为带 controls 的 `<video>`，地址同图片（旧签名 URL，票据凭证走 blob:，票据不进 URL）。
- 宿主插槽（0.1.3，默认都不启用，不传则 DOM / 布局与 0.1.2 完全一致）：
  ```js
  createSupportWidget({
    session, mode: 'inline',
    slots: {
      composeStart: (box, ctx) => { box.append(myScreenshotButton); },   // 输入框下方工具行左侧（附件按钮之前，32px 图标钮同行同高，发送右对齐）
      aboveCompose: (box) => { box.append(myThumbsOrRecordingBar); },    // 0.1.4：列表与输入框之间的固定区（缩略图 / 录屏状态），占自己高度，不覆盖消息
      aboveList: myToolbarNode,                                          // 头部与消息列表之间
    },
    header: {
      variant: 'actions',                        // 0.1.4：'default' | 'compact' | 'actions' | 'none'
      start: (box) => mountMyDragHandle(box),   // 标题之前（拖拽手柄 / 返回）
      end: myThemeToggleNode,                   // 模式按钮与关闭按钮之间
    },
    onClose: () => host.hide(),                 // 点关闭 / 浮动模式 Esc；inline 因此显示关闭按钮
  });
  ```
  插槽值是 `Node`，或 `(container, ctx) => void | Node | cleanup`：函数拿到 Widget 专用容器（`[data-slot]`），宿主在里面自行挂载（如 React `createRoot(container)`），返回的函数在 `destroy()` 时调用。Widget 不移动宿主已有节点、不用 innerHTML / eval；插槽或 `onClose` 抛错不影响客服主流程。会话模式 / 转人工按钮仍由 Widget 保留。类型见 `widget.js` 顶部 JSDoc（`SupportSlot` / `SupportSlots` / `SupportHeader`）。
- 0.1.4 视觉与布局：头部改为表面色（不再整条品牌色；主色只用于发送按钮、用户气泡、发言标识、焦点环，且保证 ≥4.5:1 对比度）；气泡用逻辑属性做单角小圆角（用户 `border-end-end-radius`、客服 `border-end-start-radius`，RTL 自动翻转）；输入区是**一个 composer 框**：上 textarea，下一条工具行（左：`composeStart` 槽 + 附件，右：发送）。`header.variant`：`default` 完整头；`compact` 单行「模式文字 + 转人工 / 返回 AI + 槽位 + 关闭」；`actions` 宿主已有标题与在线条，只留右对齐的转人工 / 返回 AI（无可见内容时整条隐藏）；`none` 不渲染头部，用 `widget.toggleMode()` 转人工 / 返回 AI。非 default 变体里标题 / 模式文字仍在 DOM（读屏名称）。script 嵌入可用 `data-header`。`widget.version` / `widget.features` 供宿主特性检测。inline 模式的容器需有确定高度（或是 flex 子项）；`.stage`（列表）自身滚动，头部 / 状态区 / composer 固定，「N 条新消息」浮在列表底部。`composeStart` 内的 `<button>` 有低优先级默认样式（32px 透明图标钮，`data-state="recording"` 为红色），宿主样式可覆盖。插槽容器 `.slot:empty` 会被隐藏：不要直接在插槽容器上 `attachShadow`（没有 light DOM 子节点的 shadow host 仍算 `:empty`），应先在容器里放一个子元素，再给它挂 shadow root。
- 0.1.6 浮动面板可拖动：`mode:'floating'`（默认）按住**头部标题栏空白处**拖动面板，启动按钮不动。鼠标 / 触摸 / 笔统一走 pointer events + pointer capture，`pointercancel` / 丢失捕获即收尾；以 CSS `translate` 偏移（相对默认右下 / 左下锚点），RTL 不受影响。按在关闭 / 转人工 / 链接 / 按钮 / 输入等交互元素（含宿主头部槽位里的）上不拖动；消息列表、输入框、附件不在拖动区。位置夹在可视区内（边距 8px），视口 resize 与重新展开时自动夹紧（用户期望的位置另存，视口变大后可回到原处）；收起再展开位置保持。
  - 选项 `draggable`：`true`（默认）/ `false` / `{ persist?: true | 'storageKey', margin?: 8, storage?: Storage }`。`persist` 才写 localStorage（默认键 `webcode-support:panel-position`，存取失败静默忽略），默认只在内存里记。script 嵌入：`data-draggable="false"`、`data-drag-persist="true"`。
  - API：`widget.getPosition()` → `{x,y,moved}`、`widget.setPosition({x,y})`、`widget.resetPosition()`（回默认并清存储；inline / `draggable:false` / `header.variant:'none'` 时返回 `false`）。宿主属性 `data-draggable` / `data-moved` / `data-dragging` 可用于样式。
  - **inline 不内建拖动**，宿主（如 CCDub 的 SupportWindow）继续自己定位，互不冲突。宿主想复用同一套指针处理：`import { attachDragHandle } from '@webcode/support-ui/widget'`，`attachDragHandle(handleEl, { onStart, onMove({dx,dy}), onEnd({canceled}), ignore })` 返回 `detach()`；它只报告位移，不碰定位，默认忽略按钮 / 链接 / 输入 / `[data-no-drag]`。手机窄屏面板几乎占满，仅剩少量纵向可拖空间。`widget.features` 含 `draggable`、`dragHandle`。
- 0.1.5（照 WebClaw Store 客服面板）：输入区是 **一个带边框的 `.field`**：宿主预览槽 `slots.aboveInputPreview` → 待发缩略图托盘（图片 / `<video muted>` 首帧，带删除、上传中遮罩）→ textarea → 工具行（左：`composeStart` 槽 + 附件；右：圆形发送，无内容时禁用）。转人工 / 返回 AI 与状态文字默认移到列表与输入框之间的细状态条 `.handoff`；`header.handoff: 'header' | 'footer' | 'none'` 可改位置（compact/actions 变体默认 header，none 变体默认 none）；`slots.footer` 在状态条内放宿主状态 / 错误 / 录制计时。头部：`title` + 可选 `subtitle`（`widget.setSubtitle(text)` 动态改）+ 关闭；用户气泡为淡主色底，人工客服气泡有侧边色带，一侧尖角。
  - 附件：`widget.addFiles(files)` 返回 `Promise<{accepted, rejected:[{file, reason}]}>`，`reason` 为 `type | rejected | too_large | too_many`；`getFiles()`。选文件、粘贴图片（只拦截符合 `accept` 的文件，纯文本照常粘贴）、宿主 addFiles 走同一条校验：`accept` → `beforeUpload(file, ctx)`（`ctx.files` = 已选 + 本批已接受）→ 大小（`maxImageBytes` 默认 2MB、`maxVideoBytes` 默认 4MB，与服务端一致）→ 名额（`maxFiles` 总数 ≤ 6；可选 `maxImages` / `maxVideos` 分类型名额，如 CCDub 的 3 图 + 1 录屏）。发送失败时已选文件保留可重发。
  - **服务端真实支持**（`worker/src/files.js`，按文件头识别）：png / jpeg / gif / webp（≤2MB）、webm（≤4MB）；**不接受 mp4**。默认 `accept` 仅图片，宿主要发录屏需自行传 `accept: '...,video/webm'`，不要把 mp4 或文档写进 accept。消息里的 `.mp4` 仅是展示兼容，不代表可上传。
- 预填输入：`w.setDraft(text, { focus })`（`focus:true` 会先展开面板）、`w.getDraft()`；切身份仍清草稿。不在底部时到达的新消息会显示「N 条新消息 ↓」。
- 登录 / 登出 / 切账号：`w.resetIdentity()`。运行时换品牌 / 明暗：`w.setTheme({...})`、`w.setColorScheme('dark')`，不重建 DOM、不断会话。

| 主题参数 | 说明 |
|---|---|
| `primary` / `primaryDark` | 品牌主色；深色模式不给 `primaryDark` 时自动提亮到与背景对比度 ≥ 3。主色上的文字自动选黑/白 |
| `fontFamily` | 字体栈（默认 inherit 宿主页面） |
| `radius` | 0–28px；气泡、按钮、面板按比例派生 |
| `icon` | `chat` / `headset` / `help` / 图片 URL（https、站内绝对路径或 data:image） |
| `colorScheme` | `auto`（跟随系统）/ `light` / `dark` / `document`（跟随宿主 `<html class="dark">` 或 `data-theme`） |
| `light` / `dark` | 可选表面色覆盖 `{bg, surface, text, muted, border, agentBubble}` |

文案：`lang` + `t(key, vars)`（宿主的翻译函数，键见 `MESSAGE_KEYS`；缺的回退 en/zh）。RTL 语言自动 `dir=rtl`。

**收起 = 只查未读**：Widget 收起时调用 `session.setActive(false)`，此时推送帧和兜底定时器只调用 `/api/unread`，绝不调用 `/api/poll`（服务端规则是「拉过就算已读」）。展开时才 poll。启动按钮和面板共用一个 session，只占一条推送连接。

## 桌面端 WebView / 扩展（薄适配）

```js
import { hostCredentials, bindExtensionPush, createSupportClient, createSupportSession } from '@webcode/support-ui';
import { createSupportWidget } from '@webcode/support-ui/widget';

// 桌面：原生侧签发票据（Tauri invoke / WebView2 postMessage），页面只拿结果；inline 铺满窗口
const credentials = hostCredentials({ app: 'ai-studio', request: () => invoke('support_ticket') });
const session = createSupportSession({ client: createSupportClient({ credentials }) });
createSupportWidget({ session, mode: 'inline', container: el, titleBadge: true /* CCDub Desktop 外壳读 "(N) " */ });

// 扩展：background 已持有 events 长连接 → push:'external'，把 runtime 广播喂进来
const s = createSupportSession({ client, push: 'external' });
const off = bindExtensionPush(s, chrome.runtime); // supportNotify / supportTypingEvent(只认本 uid) / supportWatchState
```

## 核心 API（自建 UI 时）

```js
import {
  siteSessionCredentials, ticketCredentials, createSupportClient, createSupportSession, canRate,
} from '@webcode/support-ui';
import { useSupportState, useSupportSessionLifecycle, useActiveTyping } from '@webcode/support-ui/react';

// 1) 凭证：二选一
const credentials = siteSessionCredentials({ expectApp: 'ccdub' });      // 同源 /api/support/session
// const credentials = ticketCredentials({ app: 'ai-studio' });          // 同源 /api/support/token（ES256 票据）

// 2) 客户端 + 会话（每个产品面板建一次）
const client = createSupportClient({ credentials, getToken: () => localStorage.getItem('ccdub_support_token') });
const session = createSupportSession({ client, push: 'websocket' });     // 扩展用 'external'

// 3) React
function Panel({ open }) {
  useSupportSessionLifecycle(React, session, { enabled: open });
  const s = useSupportState(React, session.store);
  const typing = useActiveTyping(React, session.store);                  // 'ai' | 'human' | null
  // s.messages[i].kind: 'user' | 'ai' | 'human' | 'system'；s.pending：乐观消息
  // s.supportMode: 'ai' | 'human_requested' | 'human'
  // session.send({text, files, lang, meta}) / requestHuman() / resumeAi() / rate(id, 'down', {reason})
  // canRate(s, m) 决定是否显示赞踩；原因 FEEDBACK_REASONS（6 种）
}

// 登录 / 登出 / 切账号
session.resetIdentity();
```

## 关键不变式

| 主题 | 规则 |
|---|---|
| 账号隔离 | 状态按 `app|uid` 分桶；身份变化清空并从 `since=0` 重拉；旧身份迟到结果丢弃 |
| 凭证 | 旧签名放 query/body；票据只放 `Authorization`，不进 URL/存储；401 强制重取并只重试一次；凭证含 secret 形字段即拒绝；`expectApp` 防串产品 |
| 推送 | 连着时零周期请求；断线 5s poll；退避 1s→30s；80% TTL 静默换票不断流；连接只按身份建立 |
| typing | 只认不更旧的 `rev`；新回复到达即清；最长 45s；推送不可用或 `typing_push=false` 才 2s 兜底，且仅可见 + 会话进行中 |
| 模式 | 服务端为准；本地动作后的旧 poll 不覆盖（modeSeq）；409 带回的 `mode` 直接校正 |
| 评价 | 只 `kind=ai && rateable && feedback_enabled`；服务端确认才改；`unavailable` 收起全部、`not_found/not_rateable` 收起单条 |
| 未读角标 | `(N) 标题` 纯数字不封顶（CCDub Desktop 外壳只认 1~2 位数字）；Widget 按钮上视觉封顶 99+ |
| 收起态 | `setActive(false)` 只查 `/api/unread`，不 poll（poll 会把回复标成已读） |
| 渲染 | 正文一律 `textContent`；`innerHTML` 只用于包内常量图标（有静态测试守着） |
| 主题 | 颜色只收 `#rgb/#rrggbb`，字体栈禁 `; { } < > \ @`，图标只收 https / 站内路径 / data:image；非法即回退 |

## 同源示范接入（本地，零外网）

```bash
npm run demo        # http://127.0.0.1:8787  —— 网站服务端 :8787 签凭证，真实 Worker 在 :8788（跨源 + CORS）
```

- `aurora.html`：一行 script，app=ccdub，紫色 / Inter / 大圆角，明暗跟随宿主 `<html class>`
- `ember.html`：`WebcodeSupport.mount()`，app=webclaw，橙色 + `primaryDark` / 衬线 / 小圆角 / 左下角，运行时 `setColorScheme`
- `studio.html`：短期票据，app=ai-studio，ticket_only（同源 `/studio/api/support/token` 在服务端签 ES256，浏览器只拿票）
- `desktop.html`：ESM + `hostCredentials` + inline
- 每页都能切账号（服务端 cookie 决定 uid → `resetIdentity()`），也能模拟客服（AI 回答 / 人工输入 / 人工回复走真实 `/admin/api/*`）

## 测试

```bash
npm test                                   # 单元 + Widget(jsdom) + 对同仓库 Worker 的契约测试（旧签名 + 票据）
npm run test:browser                       # Playwright 真浏览器 × 真 Worker：完整流程、账号隔离、两品牌 × 明暗、桌面 inline、Studio 票据 + 附件 blob；截图在 test-results/
npm run lint && npm run build

# 对着别的 Worker 版本跑（例如线上发布分支导出的副本；没有 src/auth.js 时票据用例自动跳过）
git archive <ref> worker | tar -x -C /tmp/tw      # 在仓库根执行
SUPPORT_WORKER_SRC=/tmp/tw/worker npm test
```

开发依赖（jsdom / rollup / playwright / eslint）不随包发布；本仓库 worktree 里可把 `node_modules` 软链到主仓库的 node_modules（已 gitignore）。

需要 Node ≥ 22.5（`node:sqlite`、`module.registerHooks`）。
